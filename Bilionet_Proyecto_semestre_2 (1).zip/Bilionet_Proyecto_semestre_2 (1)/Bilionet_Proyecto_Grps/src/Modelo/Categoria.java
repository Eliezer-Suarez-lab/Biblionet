package Modelo;

public class Categoria {

    private int id_categoria;
    private String nombre_categoria;

    // Constructor vacío
    public Categoria() {
    }

    // Constructor completo con id_categoria
    public Categoria(int id_categoria, String nombre_categoria) {
        this.id_categoria = id_categoria;
        this.nombre_categoria = nombre_categoria;
    }

    // Constructor sin id_categoria (para registros)
    public Categoria(String nombre_categoria) {
        this.nombre_categoria = nombre_categoria;
    }

    // Getters y Setters
    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public String getNombre_categoria() {
        return nombre_categoria;
    }

    public void setNombre_categoria(String nombre_categoria) {
        this.nombre_categoria = nombre_categoria;
    }

    // Alias para compatibilidad
    public String getNombre() {
        return nombre_categoria;
    }

    public void setNombre(String nombre) {
        this.nombre_categoria = nombre;
    }

    @Override
    public String toString() {
        return (nombre_categoria != null) ? nombre_categoria : "";
    }
}
