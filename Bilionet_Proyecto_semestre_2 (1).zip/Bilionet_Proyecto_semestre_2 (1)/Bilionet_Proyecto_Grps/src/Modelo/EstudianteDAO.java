package Modelo;

import Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

// Se encarga de administrar toda la información de los estudiantes de la biblioteca.
public class EstudianteDAO {

    // Obtiene la lista con todos los estudiantes registrados en el sistema.
    public List<Estudiante> listar() {
        List<Estudiante> lista = new ArrayList<>();
        String sql = "{CALL sp_listar_estudiantes()}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            while (rs.next()) {
                Estudiante e = new Estudiante();
                e.setCodigo(rs.getInt("codigo"));
                e.setNombres(rs.getString("nombres"));
                e.setApellidos(rs.getString("apellidos"));
                e.setTelefono(rs.getString("telefono"));
                e.setTipo_usuario(rs.getString("tipo_usuario"));
                e.setSeccion(rs.getString("seccion"));
                e.setAnio(rs.getString("anio"));
                lista.add(e);
            }

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_listar_estudiantes en EstudianteDAO: " + ex.getMessage());
        }

        return lista;
    }

    // Guarda a un nuevo estudiante con sus datos personales, grado y sección.
    public boolean registrar(Estudiante estudiante) {
        String sql = "{CALL sp_insertar_estudiante(?, ?, ?, ?, ?, ?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setString(1, estudiante.getNombres());
            cs.setString(2, estudiante.getApellidos());
            cs.setString(3, estudiante.getTelefono());
            cs.setString(4, estudiante.getTipo_usuario());
            cs.setString(5, estudiante.getSeccion());
            cs.setString(6, estudiante.getAnio());

            cs.execute();
            return true;

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_insertar_estudiante en EstudianteDAO: " + ex.getMessage());
            return false;
        }
    }

    // Guarda las modificaciones realizadas a los datos de un estudiante registrado.
    public boolean actualizar(Estudiante estudiante) {
        String sql = "{CALL sp_actualizar_estudiante(?, ?, ?, ?, ?, ?, ?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setInt(1, estudiante.getCodigo());
            cs.setString(2, estudiante.getNombres());
            cs.setString(3, estudiante.getApellidos());
            cs.setString(4, estudiante.getTelefono());
            cs.setString(5, estudiante.getTipo_usuario());
            cs.setString(6, estudiante.getSeccion());
            cs.setString(7, estudiante.getAnio());

            cs.execute();
            return true;

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_actualizar_estudiante en EstudianteDAO: " + ex.getMessage());
            return false;
        }
    }

    // Da de baja o retira a un estudiante del sistema usando su código.
    public boolean eliminar(int codigo) {
        String sql = "{CALL sp_eliminar_estudiante(?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setInt(1, codigo);

            cs.execute();
            return true;

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_eliminar_estudiante en EstudianteDAO: " + ex.getMessage());
            return false;
        }
    }

    // Busca estudiantes cuyos datos coincidan con el texto que escribimos.
    public List<Estudiante> buscar(String filtro) {
        List<Estudiante> lista = new ArrayList<>();
        String sql = "{CALL sp_buscar_estudiantes(?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setString(1, filtro != null ? filtro.trim() : "");

            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    Estudiante e = new Estudiante();
                    e.setCodigo(rs.getInt("codigo"));
                    e.setNombres(rs.getString("nombres"));
                    e.setApellidos(rs.getString("apellidos"));
                    e.setTelefono(rs.getString("telefono"));
                    e.setTipo_usuario(rs.getString("tipo_usuario"));
                    e.setSeccion(rs.getString("seccion"));
                    e.setAnio(rs.getString("anio"));
                    lista.add(e);
                }
            }

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_buscar_estudiantes en EstudianteDAO: " + ex.getMessage());
        }

        return lista;
    }

    // Averigua cuál es el siguiente número disponible para registrar a un nuevo estudiante.
    public int obtenerSiguienteId() {
        String sql = "{CALL sp_obtener_siguiente_id_estudiante()}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("siguiente_id");
            }

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_obtener_siguiente_id_estudiante en EstudianteDAO: " + ex.getMessage());
        }

        return 1;
    }
}
