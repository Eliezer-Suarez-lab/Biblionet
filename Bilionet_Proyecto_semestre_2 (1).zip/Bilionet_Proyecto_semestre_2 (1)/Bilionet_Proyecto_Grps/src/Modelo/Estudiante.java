package Modelo;

/**
 * Clase Modelo que representa la entidad Estudiante (tabla estudiantes).
 */
public class Estudiante {

    private int codigo;
    private String nombres;
    private String apellidos;
    private String telefono;
    private String tipo_usuario;
    private String seccion;
    private String anio;

    // Constructor vacío
    public Estudiante() {
    }

    // Constructor completo con todos los atributos
    public Estudiante(int codigo, String nombres, String apellidos, String telefono, String tipo_usuario, String seccion, String anio) {
        this.codigo = codigo;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.tipo_usuario = tipo_usuario;
        this.seccion = seccion;
        this.anio = anio;
    }

    // Constructor sin código (para nuevos registros)
    public Estudiante(String nombres, String apellidos, String telefono, String tipo_usuario, String seccion, String anio) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.tipo_usuario = tipo_usuario;
        this.seccion = seccion;
        this.anio = anio;
    }

    // Getters y Setters
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getTipo_usuario() {
        return tipo_usuario;
    }

    public void setTipo_usuario(String tipo_usuario) {
        this.tipo_usuario = tipo_usuario;
    }

    // Alias camelCase para compatibilidad
    public String getTipoUsuario() {
        return tipo_usuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipo_usuario = tipoUsuario;
    }

    public String getSeccion() {
        return seccion;
    }

    public void setSeccion(String seccion) {
        this.seccion = seccion;
    }

    public String getAnio() {
        return anio;
    }

    public void setAnio(String anio) {
        this.anio = anio;
    }

    @Override
    public String toString() {
        return this.nombres + " " + this.apellidos;
    }
}
