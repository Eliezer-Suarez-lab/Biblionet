package Modelo;

public class Libro {

    private int cod_libro;
    private String libro;
    private int id_autor;
    private String edicion;
    private int id_categoria;
    private int cantidad;

    // Campos complementarios obtenidos mediante INNER JOIN para mostrar en la interfaz
    private String autor;      // Nombre completo del autor
    private String categoria;  // Nombre de la categoría

    // Constructor vacío
    public Libro() {
    }

    // Constructor con IDs foráneos (para inserciones o actualizaciones desde formularios)
    public Libro(int cod_libro, String libro, int id_autor, String edicion, int id_categoria, int cantidad) {
        this.cod_libro = cod_libro;
        this.libro = libro;
        this.id_autor = id_autor;
        this.edicion = edicion;
        this.id_categoria = id_categoria;
        this.cantidad = cantidad;
    }

    // Constructor sin cod_libro con IDs (para registros nuevos)
    public Libro(String libro, int id_autor, String edicion, int id_categoria, int cantidad) {
        this.libro = libro;
        this.id_autor = id_autor;
        this.edicion = edicion;
        this.id_categoria = id_categoria;
        this.cantidad = cantidad;
    }

    // Constructor completo con nombres de relaciones (resultado de consultas INNER JOIN)
    public Libro(int cod_libro, String libro, int id_autor, String autor, String edicion, int id_categoria, String categoria, int cantidad) {
        this.cod_libro = cod_libro;
        this.libro = libro;
        this.id_autor = id_autor;
        this.autor = autor;
        this.edicion = edicion;
        this.id_categoria = id_categoria;
        this.categoria = categoria;
        this.cantidad = cantidad;
    }

    // Constructor simplificado para visualización directa en tabla
    public Libro(int cod_libro, String libro, String autor, String edicion, String categoria, int cantidad) {
        this.cod_libro = cod_libro;
        this.libro = libro;
        this.autor = autor;
        this.edicion = edicion;
        this.categoria = categoria;
        this.cantidad = cantidad;
    }

    // Getters y Setters
    public int getCod_libro() {
        return cod_libro;
    }

    public void setCod_libro(int cod_libro) {
        this.cod_libro = cod_libro;
    }

    public String getLibro() {
        return libro;
    }

    public void setLibro(String libro) {
        this.libro = libro;
    }

    // Alias por si se referencia como título
    public String getTitulo() {
        return libro;
    }

    public void setTitulo(String titulo) {
        this.libro = titulo;
    }

    public int getId_autor() {
        return id_autor;
    }

    public void setId_autor(int id_autor) {
        this.id_autor = id_autor;
    }

    public String getEdicion() {
        return edicion;
    }

    public void setEdicion(String edicion) {
        this.edicion = edicion;
    }

    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return this.libro;
    }
}
