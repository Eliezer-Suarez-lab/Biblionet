package Modelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

// Encargado de consultar y buscar la información de los autores de los libros en la biblioteca.
public class AutorDAO {

    // Obtiene la lista completa de todos los autores guardados en la biblioteca.
    public List<Autor> listar() {
        List<Autor> lista = new ArrayList<>();
        String sql = "SELECT id_autor, nombres, apellidos, nacionalidad FROM autor ORDER BY nombres, apellidos ASC";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Autor a = new Autor();
                a.setId_autor(rs.getInt("id_autor"));
                a.setNombres(rs.getString("nombres"));
                a.setApellidos(rs.getString("apellidos"));
                a.setNacionalidad(rs.getString("nacionalidad"));
                lista.add(a);
            }

        } catch (SQLException e) {
            System.err.println("Error al listar autores en AutorDAO: " + e.getMessage());
        }

        return lista;
    }

    // Busca los datos de un autor usando su número de registro.
    public Autor buscarPorId(int id) {
        String sql = "SELECT id_autor, nombres, apellidos, nacionalidad FROM autor WHERE id_autor = ?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Autor(
                            rs.getInt("id_autor"),
                            rs.getString("nombres"),
                            rs.getString("apellidos"),
                            rs.getString("nacionalidad")
                    );
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar autor por ID en AutorDAO: " + e.getMessage());
        }

        return null;
    }
}
