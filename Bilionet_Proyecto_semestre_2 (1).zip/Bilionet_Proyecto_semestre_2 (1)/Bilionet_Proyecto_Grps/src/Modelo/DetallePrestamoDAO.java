package Modelo;

import Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

// Maneja los libros individuales que forman parte de cada préstamo realizado.
public class DetallePrestamoDAO {

    // Guarda un libro dentro del préstamo y descuenta una copia del inventario.
    public boolean insertar(DetallePrestamo detalle) {
        String sql = "{CALL sp_insertar_detalle_prestamo(?, ?, ?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setInt(1, detalle.getId_prestamo());
            cs.setInt(2, detalle.getCod_libro());
            cs.setInt(3, detalle.getCantidad() > 0 ? detalle.getCantidad() : 1);

            cs.execute();
            return true;

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_insertar_detalle_prestamo en DetallePrestamoDAO: " + ex.getMessage());
            return false;
        }
    }

    // Muestra cuáles libros pertenecen a un préstamo en específico.
    public List<DetallePrestamo> listarPorPrestamo(int idPrestamo) {
        List<DetallePrestamo> lista = new ArrayList<>();
        String sql = "SELECT dp.id_detalle, dp.id_prestamo, dp.cod_libro, dp.cantidad, " +
                     "l.libro AS tituloLibro, " +
                     "CONCAT(a.nombres, ' ', a.apellidos) AS autorLibro, " +
                     "c.nombre_categoria AS categoriaLibro " +
                     "FROM detalle_prestamos dp " +
                     "INNER JOIN libros l ON dp.cod_libro = l.cod_libro " +
                     "INNER JOIN autor a ON l.id_autor = a.id_autor " +
                     "INNER JOIN categoria c ON l.id_categoria = c.id_categoria " +
                     "WHERE dp.id_prestamo = ?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idPrestamo);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    DetallePrestamo dp = new DetallePrestamo();
                    dp.setId_detalle(rs.getInt("id_detalle"));
                    dp.setId_prestamo(rs.getInt("id_prestamo"));
                    dp.setCod_libro(rs.getInt("cod_libro"));
                    dp.setCantidad(rs.getInt("cantidad"));
                    dp.setTituloLibro(rs.getString("tituloLibro"));
                    dp.setAutorLibro(rs.getString("autorLibro"));
                    dp.setCategoriaLibro(rs.getString("categoriaLibro"));
                    lista.add(dp);
                }
            }

        } catch (SQLException ex) {
            System.err.println("Error al listar detalles por préstamo en DetallePrestamoDAO: " + ex.getMessage());
        }

        return lista;
    }
}
