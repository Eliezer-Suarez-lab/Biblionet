package Modelo;

import Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

// Maneja las devoluciones y consulta qué libros faltan por ser entregados.
public class DevolucionDAO {

    // Busca los préstamos que aún tienen libros pendientes por devolver.
    public List<Devolucion> listarPendientes(String criterio) {
        List<Devolucion> lista = new ArrayList<>();
        String sql = "{CALL sp_listar_prestamos_pendientes(?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            if (criterio != null && !criterio.trim().isEmpty()) {
                cs.setString(1, criterio.trim());
            } else {
                cs.setString(1, null);
            }

            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    Devolucion dev = new Devolucion();
                    dev.setId_prestamo(rs.getInt("id_prestamo"));
                    dev.setTituloLibro(rs.getString("libros_prestados"));
                    dev.setNombreEstudiante(rs.getString("nombreEstudiante"));
                    Date fPrestamo = rs.getDate("fecha_prestamo");
                    if (fPrestamo != null) {
                        dev.setFecha_prestamo(fPrestamo.toLocalDate());
                    }
                    Date fDevolucion = rs.getDate("fecha_devolucion");
                    if (fDevolucion != null) {
                        dev.setFecha_devolucion(fDevolucion.toLocalDate());
                    }
                    dev.setDiasRestantes(rs.getInt("dias_restantes"));
                    lista.add(dev);
                }
            }

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_listar_prestamos_pendientes en DevolucionDAO: " + ex.getMessage());
        }

        return lista;
    }

    // Busca un préstamo pendiente usando el texto o código que escribimos.
    public List<Devolucion> buscarPorId(String idTexto) {
        return listarPendientes(idTexto);
    }

    // Busca un préstamo pendiente usando su número.
    public List<Devolucion> buscarPorId(int id) {
        return listarPendientes(String.valueOf(id));
    }

    // Obtiene todos los préstamos que tienen libros pendientes de entrega.
    public List<Devolucion> listarPendientes() {
        return listarPendientes(null);
    }

    // Marca como devueltos todos los libros de un préstamo y los regresa al inventario para que puedan prestarse otra vez.
    public boolean registrarDevolucionPorPrestamo(int idPrestamo) {
        String sql = "{CALL sp_registrar_devolucion_por_prestamo(?, ?, ?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setInt(1, idPrestamo);
            cs.setString(2, "Entregado");
            cs.setString(3, "Devolución registrada en sistema");

            cs.execute();
            return true;

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_registrar_devolucion_por_prestamo en DevolucionDAO: " + ex.getMessage());
            return false;
        }
    }

    // Registra la entrega de los libros con las notas correspondientes.
    public boolean registrarDevolucion(Devolucion devolucion) {
        if (devolucion == null) {
            return false;
        }

        String sql = "{CALL sp_registrar_devolucion_por_prestamo(?, ?, ?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setInt(1, devolucion.getId_prestamo());
            cs.setString(2, devolucion.getEstado() != null ? devolucion.getEstado() : "Entregado");
            cs.setString(3, devolucion.getObservaciones() != null ? devolucion.getObservaciones() : "Devolución registrada en sistema");

            cs.execute();
            return true;

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_registrar_devolucion_por_prestamo en DevolucionDAO: " + ex.getMessage());
            return false;
        }
    }
}
