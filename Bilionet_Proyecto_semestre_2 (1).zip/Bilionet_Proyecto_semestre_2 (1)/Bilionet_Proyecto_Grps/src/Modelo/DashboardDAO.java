package Modelo;

import Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.table.DefaultTableModel;

// Obtiene las cifras, estadísticas y préstamos recientes para la pantalla principal.
public class DashboardDAO {

    // Cuenta cuántos libros hay en total en el inventario de la biblioteca.
    public int contarTotalLibros() {
        String sql = "{CALL sp_dashboard_total_libros()}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("total_libros");
            }

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_dashboard_total_libros en DashboardDAO: " + ex.getMessage());
        }

        return 0;
    }

    // Cuenta cuántos libros están actualmente prestados a los estudiantes.
    public int contarPrestamosActivos() {
        String sql = "{CALL sp_dashboard_prestamos_activos()}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("prestamos_activos");
            }

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_dashboard_prestamos_activos en DashboardDAO: " + ex.getMessage());
        }

        return 0;
    }

    // Cuenta cuántos préstamos ya vencieron y no han sido devueltos a tiempo.
    public int contarDevolucionesPendientes() {
        String sql = "{CALL sp_dashboard_morosos()}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("morosos");
            }

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_dashboard_morosos en DashboardDAO: " + ex.getMessage());
        }

        return 0;
    }

    // Obtiene la lista de los últimos 5 préstamos realizados para mostrarlos en la pantalla.
    public DefaultTableModel obtenerActividadReciente() {
        String[] columnas = {"Nombre", "Libro", "Préstamo"};
        DefaultTableModel modelo = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        String sql = "{CALL sp_dashboard_actividad_reciente()}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            while (rs.next()) {
                Object[] fila = new Object[3];
                fila[0] = rs.getString("estudiante");
                fila[1] = rs.getString("libro");
                fila[2] = rs.getDate("fecha_prestamo");
                modelo.addRow(fila);
            }

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_dashboard_actividad_reciente en DashboardDAO: " + ex.getMessage());
        }

        return modelo;
    }

    // Organiza la cantidad de préstamos hechos en cada mes para armar la gráfica del año.
    public Map<String, Integer> obtenerPrestamosPorMes() {
        Map<String, Integer> mapaMeses = new LinkedHashMap<>();
        String[] nombresMeses = {"Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"};

        for (String mes : nombresMeses) {
            mapaMeses.put(mes, 0);
        }

        String sql = "{CALL sp_dashboard_prestamos_por_mes()}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            while (rs.next()) {
                int numMes = rs.getInt("mes_num");
                int total = rs.getInt("total");
                if (numMes >= 1 && numMes <= 12) {
                    mapaMeses.put(nombresMeses[numMes - 1], total);
                }
            }

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_dashboard_prestamos_por_mes en DashboardDAO: " + ex.getMessage());
        }

        return mapaMeses;
    }
}
