package Modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase Modelo que representa la entidad Prestamo (tabla prestamos).
 */
public class Prestamo {

    private int id_prestamo;
    private int id_estudiante;
    private LocalDate fecha_prestamo;
    private LocalDate fecha_devolucion;

    // Atributos complementarios para presentación en interfaz
    private String nombreEstudiante;
    private List<DetallePrestamo> detalles;

    // Constructor vacío
    public Prestamo() {
        this.detalles = new ArrayList<>();
    }

    // Constructor completo con ID
    public Prestamo(int id_prestamo, int id_estudiante, LocalDate fecha_prestamo, LocalDate fecha_devolucion) {
        this.id_prestamo = id_prestamo;
        this.id_estudiante = id_estudiante;
        this.fecha_prestamo = fecha_prestamo;
        this.fecha_devolucion = fecha_devolucion;
        this.detalles = new ArrayList<>();
    }

    // Constructor sin ID (para inserciones)
    public Prestamo(int id_estudiante, LocalDate fecha_prestamo, LocalDate fecha_devolucion) {
        this.id_estudiante = id_estudiante;
        this.fecha_prestamo = fecha_prestamo;
        this.fecha_devolucion = fecha_devolucion;
        this.detalles = new ArrayList<>();
    }

    // Getters y Setters
    public int getId_prestamo() {
        return id_prestamo;
    }

    public void setId_prestamo(int id_prestamo) {
        this.id_prestamo = id_prestamo;
    }

    public int getId_estudiante() {
        return id_estudiante;
    }

    public void setId_estudiante(int id_estudiante) {
        this.id_estudiante = id_estudiante;
    }

    public LocalDate getFecha_prestamo() {
        return fecha_prestamo;
    }

    public void setFecha_prestamo(LocalDate fecha_prestamo) {
        this.fecha_prestamo = fecha_prestamo;
    }

    public LocalDate getFecha_devolucion() {
        return fecha_devolucion;
    }

    public void setFecha_devolucion(LocalDate fecha_devolucion) {
        this.fecha_devolucion = fecha_devolucion;
    }

    public String getNombreEstudiante() {
        return nombreEstudiante;
    }

    public void setNombreEstudiante(String nombreEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
    }

    public List<DetallePrestamo> getDetalles() {
        return detalles;
    }

    public void setDetalles(List<DetallePrestamo> detalles) {
        this.detalles = detalles;
    }
}
