package Modelo;

import java.time.LocalDate;

/**
 * Clase Modelo que representa la entidad Devolucion (tabla devoluciones).
 */
public class Devolucion {

    private int id_devolucion;
    private int id_prestamo;
    private int cod_libro;
    private LocalDate fecha_entrega;
    private String estado;
    private String observaciones;

    // Atributos complementarios para presentación en la vista Devoluciones
    private String tituloLibro;
    private String nombreEstudiante;
    private LocalDate fecha_prestamo;
    private LocalDate fecha_devolucion;
    private int diasRestantes;

    // Constructor vacío
    public Devolucion() {
        this.fecha_entrega = LocalDate.now();
        this.estado = "Entregado";
    }

    // Constructor para registrar una nueva devolución
    public Devolucion(int id_prestamo, int cod_libro, LocalDate fecha_entrega, String estado, String observaciones) {
        this.id_prestamo = id_prestamo;
        this.cod_libro = cod_libro;
        this.fecha_entrega = fecha_entrega;
        this.estado = estado;
        this.observaciones = observaciones;
    }

    // Constructor completo con ID
    public Devolucion(int id_devolucion, int id_prestamo, int cod_libro, LocalDate fecha_entrega, String estado, String observaciones) {
        this.id_devolucion = id_devolucion;
        this.id_prestamo = id_prestamo;
        this.cod_libro = cod_libro;
        this.fecha_entrega = fecha_entrega;
        this.estado = estado;
        this.observaciones = observaciones;
    }

    // Constructor para visualización en tabla de préstamos pendientes por devolver
    public Devolucion(int id_prestamo, int cod_libro, String tituloLibro, String nombreEstudiante, int diasRestantes) {
        this.id_prestamo = id_prestamo;
        this.cod_libro = cod_libro;
        this.tituloLibro = tituloLibro;
        this.nombreEstudiante = nombreEstudiante;
        this.diasRestantes = diasRestantes;
        this.fecha_entrega = LocalDate.now();
        this.estado = "Entregado";
    }

    // Getters y Setters
    public int getId_devolucion() {
        return id_devolucion;
    }

    public void setId_devolucion(int id_devolucion) {
        this.id_devolucion = id_devolucion;
    }

    public int getId_prestamo() {
        return id_prestamo;
    }

    public void setId_prestamo(int id_prestamo) {
        this.id_prestamo = id_prestamo;
    }

    public int getCod_libro() {
        return cod_libro;
    }

    public void setCod_libro(int cod_libro) {
        this.cod_libro = cod_libro;
    }

    public LocalDate getFecha_entrega() {
        return fecha_entrega;
    }

    public void setFecha_entrega(LocalDate fecha_entrega) {
        this.fecha_entrega = fecha_entrega;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getTituloLibro() {
        return tituloLibro;
    }

    public void setTituloLibro(String tituloLibro) {
        this.tituloLibro = tituloLibro;
    }

    public String getNombreEstudiante() {
        return nombreEstudiante;
    }

    public void setNombreEstudiante(String nombreEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
    }

    public LocalDate getFecha_prestamo() {
        return fecha_prestamo;
    }

    public void setFecha_prestamo(LocalDate fecha_prestamo) {
        this.fecha_prestamo = fecha_prestamo;
    }

    public LocalDate getFecha_devolucion() {
        return fecha_devolucion;
    }

    public void setFecha_devolucion(LocalDate fecha_devolucion) {
        this.fecha_devolucion = fecha_devolucion;
    }

    public int getDiasRestantes() {
        return diasRestantes;
    }

    public void setDiasRestantes(int diasRestantes) {
        this.diasRestantes = diasRestantes;
    }

    @Override
    public String toString() {
        return "Devolucion{" +
                "id_devolucion=" + id_devolucion +
                ", id_prestamo=" + id_prestamo +
                ", cod_libro=" + cod_libro +
                ", fecha_entrega=" + fecha_entrega +
                ", estado='" + estado + '\'' +
                '}';
    }
}
