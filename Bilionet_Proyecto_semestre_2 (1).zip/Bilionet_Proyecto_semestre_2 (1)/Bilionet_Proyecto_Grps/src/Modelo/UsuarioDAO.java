package Modelo;

import Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

// Se encarga de administrar las cuentas de usuario y el acceso al sistema.
public class UsuarioDAO {

    // Registra una nueva cuenta de usuario con sus datos personales, correo, clave y puesto.
    public boolean insertar(Usuario usuario) {
        String sql = "INSERT INTO usuario (nombres, apellidos, correo, contraseña, rol) VALUES (?, ?, ?, ?, ?)";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, usuario.getNombres());
            ps.setString(2, usuario.getApellidos());
            ps.setString(3, usuario.getCorreo());
            ps.setString(4, usuario.getContraseña());
            ps.setString(5, usuario.getRol());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al insertar usuario en UsuarioDAO: " + e.getMessage());
            return false;
        }
    }

    // Guarda los datos de una cuenta de usuario en el sistema.
    public boolean guardar(Usuario usuario) {
        return insertar(usuario);
    }

    // Comprueba si el correo y la contraseña son válidos para permitir entrar al sistema.
    public Usuario autenticarUsuario(String correo, String contrasena) {
        String sql = "{CALL sp_validar_usuario(?, ?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setString(1, correo);
            cs.setString(2, contrasena);

            try (ResultSet rs = cs.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setId_usuario(rs.getInt("id_usuario"));
                    usuario.setNombres(rs.getString("nombres"));
                    usuario.setApellidos(rs.getString("apellidos"));
                    usuario.setCorreo(rs.getString("correo"));
                    usuario.setContraseña(contrasena);
                    usuario.setRol(rs.getString("rol"));
                    return usuario;
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al ejecutar sp_validar_usuario en UsuarioDAO: " + e.getMessage());
        }

        return null;
    }

    // Obtiene la lista completa de todas las personas con cuenta en el sistema.
    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT id_usuario, nombres, apellidos, correo, contraseña, rol FROM usuario";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Usuario u = new Usuario();
                u.setId_usuario(rs.getInt("id_usuario"));
                u.setNombres(rs.getString("nombres"));
                u.setApellidos(rs.getString("apellidos"));
                u.setCorreo(rs.getString("correo"));
                try {
                    u.setContraseña(rs.getString("contraseña"));
                } catch (SQLException ex) {
                    u.setContraseña(rs.getString("contrasena"));
                }
                u.setRol(rs.getString("rol"));
                lista.add(u);
            }

        } catch (SQLException e) {
            System.err.println("Error al listar usuarios en UsuarioDAO: " + e.getMessage());
        }

        return lista;
    }

    // Da de baja o elimina la cuenta de un usuario.
    public boolean eliminar(int id) {
        String sql = "DELETE FROM usuario WHERE id_usuario = ?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar usuario en UsuarioDAO: " + e.getMessage());
            return false;
        }
    }

    // Guarda los cambios realizados a los datos de la cuenta de un usuario.
    public boolean actualizar(Usuario u) {
        String sql = "UPDATE usuario SET nombres = ?, apellidos = ?, correo = ?, contraseña = ?, rol = ? WHERE id_usuario = ?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, u.getNombres());
            ps.setString(2, u.getApellidos());
            ps.setString(3, u.getCorreo());
            ps.setString(4, u.getContraseña());
            ps.setString(5, u.getRol());
            ps.setInt(6, u.getId_usuario());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar usuario en UsuarioDAO: " + e.getMessage());
            return false;
        }
    }
}
