package Modelo;

import Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

// Se encarga de administrar el catálogo de libros y el inventario disponible en la biblioteca.
public class LibroDAO {

    // Obtiene la lista completa de libros con sus autores, categorías y existencias.
    public List<Libro> listar() {
        List<Libro> lista = new ArrayList<>();
        String sql = "{CALL sp_listar_libros()}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            while (rs.next()) {
                Libro l = new Libro();
                l.setCod_libro(rs.getInt("cod_libro"));
                l.setLibro(rs.getString("libro"));
                l.setId_autor(rs.getInt("id_autor"));
                l.setAutor(rs.getString("autor"));
                l.setEdicion(rs.getString("edicion"));
                l.setId_categoria(rs.getInt("id_categoria"));
                l.setCategoria(rs.getString("categoria"));
                l.setCantidad(rs.getInt("cantidad"));
                lista.add(l);
            }

        } catch (SQLException e) {
            System.err.println("Error al ejecutar sp_listar_libros en LibroDAO: " + e.getMessage());
        }

        return lista;
    }

    // Agrega un nuevo libro al catálogo con sus datos y la cantidad de ejemplares disponibles.
    public boolean registrar(Libro libro) {
        String sql = "{CALL sp_insertar_libro(?, ?, ?, ?, ?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setString(1, libro.getLibro());
            cs.setInt(2, libro.getId_autor());
            cs.setString(3, libro.getEdicion());
            cs.setInt(4, libro.getId_categoria());
            cs.setInt(5, libro.getCantidad());

            cs.execute();
            return true;

        } catch (SQLException e) {
            System.err.println("Error al ejecutar sp_insertar_libro en LibroDAO: " + e.getMessage());
            return false;
        }
    }

    // Guarda los cambios realizados a los datos o existencias de un libro.
    public boolean actualizar(Libro libro) {
        String sql = "{CALL sp_actualizar_libro(?, ?, ?, ?, ?, ?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setInt(1, libro.getCod_libro());
            cs.setString(2, libro.getLibro());
            cs.setInt(3, libro.getId_autor());
            cs.setString(4, libro.getEdicion());
            cs.setInt(5, libro.getId_categoria());
            cs.setInt(6, libro.getCantidad());

            cs.execute();
            return true;

        } catch (SQLException e) {
            System.err.println("Error al ejecutar sp_actualizar_libro en LibroDAO: " + e.getMessage());
            return false;
        }
    }

    // Da de baja o elimina un libro del catálogo de la biblioteca.
    public boolean eliminar(int id) {
        String sql = "{CALL sp_eliminar_libro(?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setInt(1, id);

            cs.execute();
            return true;

        } catch (SQLException e) {
            System.err.println("Error al ejecutar sp_eliminar_libro en LibroDAO: " + e.getMessage());
            return false;
        }
    }

    // Busca libros que coincidan con el título, autor o categoría que escribimos.
    public List<Libro> buscar(String filtro) {
        List<Libro> lista = new ArrayList<>();
        String sql = "{CALL sp_buscar_libros(?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setString(1, filtro != null ? filtro.trim() : "");

            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    Libro l = new Libro();
                    l.setCod_libro(rs.getInt("cod_libro"));
                    l.setLibro(rs.getString("libro"));
                    l.setId_autor(rs.getInt("id_autor"));
                    l.setAutor(rs.getString("autor"));
                    l.setEdicion(rs.getString("edicion"));
                    l.setId_categoria(rs.getInt("id_categoria"));
                    l.setCategoria(rs.getString("categoria"));
                    l.setCantidad(rs.getInt("cantidad"));
                    lista.add(l);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al ejecutar sp_buscar_libros en LibroDAO: " + e.getMessage());
        }

        return lista;
    }

    // Averigua cuál es el siguiente número disponible para registrar un nuevo libro.
    public int obtenerSiguienteId() {
        String sql = "{CALL sp_obtener_siguiente_id_libro()}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("siguiente_id");
            }

        } catch (SQLException e) {
            System.err.println("Error al ejecutar sp_obtener_siguiente_id_libro en LibroDAO: " + e.getMessage());
        }

        return 1;
    }
}
