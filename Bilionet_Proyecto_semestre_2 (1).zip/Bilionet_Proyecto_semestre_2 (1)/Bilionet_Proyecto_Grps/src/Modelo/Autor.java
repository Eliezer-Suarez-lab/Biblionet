package Modelo;

public class Autor {

    private int id_autor;
    private String nombres;
    private String apellidos;
    private String nacionalidad;

    // Constructor vacío
    public Autor() {
    }

    // Constructor completo con id_autor
    public Autor(int id_autor, String nombres, String apellidos, String nacionalidad) {
        this.id_autor = id_autor;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.nacionalidad = nacionalidad;
    }

    // Constructor sin id_autor (para registros)
    public Autor(String nombres, String apellidos, String nacionalidad) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.nacionalidad = nacionalidad;
    }

    // Getters y Setters
    public int getId_autor() {
        return id_autor;
    }

    public void setId_autor(int id_autor) {
        this.id_autor = id_autor;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    /**
     * Retorna el nombre completo concatenado (Nombres + Apellidos).
     */
    public String getNombreCompleto() {
        String n = (nombres != null) ? nombres.trim() : "";
        String a = (apellidos != null) ? apellidos.trim() : "";
        return (n + " " + a).trim();
    }

    @Override
    public String toString() {
        return getNombreCompleto();
    }
}
