package Modelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

// Encargado de consultar las categorías o géneros de los libros.
public class CategoriaDAO {

    // Muestra todas las categorías de libros disponibles en la biblioteca.
    public List<Categoria> listar() {
        List<Categoria> lista = new ArrayList<>();
        String sql = "SELECT id_categoria, nombre_categoria FROM categoria ORDER BY nombre_categoria ASC";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Categoria c = new Categoria();
                c.setId_categoria(rs.getInt("id_categoria"));
                c.setNombre_categoria(rs.getString("nombre_categoria"));
                lista.add(c);
            }

        } catch (SQLException e) {
            System.err.println("Error al listar categorías en CategoriaDAO: " + e.getMessage());
        }

        return lista;
    }

    // Busca una categoría específica según su número de identificación.
    public Categoria buscarPorId(int id) {
        String sql = "SELECT id_categoria, nombre_categoria FROM categoria WHERE id_categoria = ?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Categoria(
                            rs.getInt("id_categoria"),
                            rs.getString("nombre_categoria")
                    );
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al buscar categoría por ID en CategoriaDAO: " + e.getMessage());
        }

        return null;
    }
}
