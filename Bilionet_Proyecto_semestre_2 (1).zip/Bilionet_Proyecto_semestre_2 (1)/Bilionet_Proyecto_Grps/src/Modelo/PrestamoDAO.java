package Modelo;

import Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

// Administra el registro y consulta de los préstamos de libros en la biblioteca.
public class PrestamoDAO {

    private String ultimoError = null;

    // Informa si ocurrió algún aviso o problema durante el préstamo (como si el estudiante ya debía libros).
    public String getUltimoError() {
        return ultimoError;
    }

    // Registra la salida de los libros prestados al estudiante y los descuenta del inventario.
    public boolean registrarPrestamo(Prestamo prestamo, List<DetallePrestamo> detalles) {
        this.ultimoError = null;
        int idPrestamo = insertar(prestamo);
        if (idPrestamo <= 0) {
            return false;
        }

        String sqlDetalle = "{CALL sp_insertar_detalle_prestamo(?, ?, ?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sqlDetalle)) {

            for (DetallePrestamo dp : detalles) {
                int cant = dp.getCantidad() > 0 ? dp.getCantidad() : 1;
                cs.setInt(1, idPrestamo);
                cs.setInt(2, dp.getCod_libro());
                cs.setInt(3, cant);
                cs.execute();
            }
            return true;

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_insertar_detalle_prestamo en PrestamoDAO: " + ex.getMessage());
            this.ultimoError = ex.getMessage();
            return false;
        }
    }

    // Guarda el préstamo con todos los libros elegidos por el estudiante.
    public boolean registrarPrestamoCompleto(Prestamo prestamo, List<DetallePrestamo> detalles) {
        return registrarPrestamo(prestamo, detalles);
    }

    // Registra la ficha inicial del préstamo con las fechas acordadas de entrega.
    public int insertar(Prestamo prestamo) {
        this.ultimoError = null;
        String sql = "{CALL sp_insertar_prestamo(?, ?, ?, ?)}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql)) {

            cs.setInt(1, prestamo.getId_estudiante());
            cs.setDate(2, Date.valueOf(prestamo.getFecha_prestamo()));
            cs.setDate(3, Date.valueOf(prestamo.getFecha_devolucion()));
            cs.registerOutParameter(4, Types.INTEGER);

            cs.execute();
            int idGenerado = cs.getInt(4);
            prestamo.setId_prestamo(idGenerado);
            return idGenerado;

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_insertar_prestamo en PrestamoDAO: " + ex.getMessage());
            this.ultimoError = ex.getMessage();
        }

        return -1;
    }

    // Obtiene la lista de todos los préstamos de libros registrados en el sistema.
    public List<Prestamo> listar() {
        List<Prestamo> lista = new ArrayList<>();
        String sql = "{CALL sp_listar_prestamos()}";

        try (Connection con = Conexion.conectar();
             CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {

            while (rs.next()) {
                Prestamo p = new Prestamo();
                p.setId_prestamo(rs.getInt("id_prestamo"));
                p.setId_estudiante(rs.getInt("id_estudiante"));
                Date fp = rs.getDate("fecha_prestamo");
                if (fp != null) {
                    p.setFecha_prestamo(fp.toLocalDate());
                }
                Date fd = rs.getDate("fecha_devolucion");
                if (fd != null) {
                    p.setFecha_devolucion(fd.toLocalDate());
                }
                p.setNombreEstudiante(rs.getString("nombreEstudiante"));
                lista.add(p);
            }

        } catch (SQLException ex) {
            System.err.println("Error al ejecutar sp_listar_prestamos en PrestamoDAO: " + ex.getMessage());
        }

        return lista;
    }
}
