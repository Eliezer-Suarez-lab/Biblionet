package Modelo;

/**
 * Clase Modelo que representa la entidad DetallePrestamo (tabla detalle_prestamos).
 */
public class DetallePrestamo {

    private int id_detalle;
    private int id_prestamo;
    private int cod_libro;
    private int cantidad;

    // Atributos complementarios para presentación en interfaz
    private String tituloLibro;
    private String autorLibro;
    private String categoriaLibro;

    // Constructor vacío
    public DetallePrestamo() {
        this.cantidad = 1;
    }

    // Constructor completo con ID
    public DetallePrestamo(int id_detalle, int id_prestamo, int cod_libro, int cantidad) {
        this.id_detalle = id_detalle;
        this.id_prestamo = id_prestamo;
        this.cod_libro = cod_libro;
        this.cantidad = cantidad;
    }

    // Constructor sin ID (para inserciones)
    public DetallePrestamo(int id_prestamo, int cod_libro, int cantidad) {
        this.id_prestamo = id_prestamo;
        this.cod_libro = cod_libro;
        this.cantidad = cantidad;
    }

    // Constructor con datos descriptivos del libro para tabla
    public DetallePrestamo(int cod_libro, String tituloLibro, String autorLibro, String categoriaLibro, int cantidad) {
        this.cod_libro = cod_libro;
        this.tituloLibro = tituloLibro;
        this.autorLibro = autorLibro;
        this.categoriaLibro = categoriaLibro;
        this.cantidad = cantidad;
    }

    // Getters y Setters
    public int getId_detalle() {
        return id_detalle;
    }

    public void setId_detalle(int id_detalle) {
        this.id_detalle = id_detalle;
    }

    public int getId_prestamo() {
        return id_prestamo;
    }

    public void setId_prestamo(int id_prestamo) {
        this.id_prestamo = id_prestamo;
    }

    public int getCod_libro() {
        return cod_libro;
    }

    public void setCod_libro(int cod_libro) {
        this.cod_libro = cod_libro;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getTituloLibro() {
        return tituloLibro;
    }

    public void setTituloLibro(String tituloLibro) {
        this.tituloLibro = tituloLibro;
    }

    public String getAutorLibro() {
        return autorLibro;
    }

    public void setAutorLibro(String autorLibro) {
        this.autorLibro = autorLibro;
    }

    public String getCategoriaLibro() {
        return categoriaLibro;
    }

    public void setCategoriaLibro(String categoriaLibro) {
        this.categoriaLibro = categoriaLibro;
    }
}
