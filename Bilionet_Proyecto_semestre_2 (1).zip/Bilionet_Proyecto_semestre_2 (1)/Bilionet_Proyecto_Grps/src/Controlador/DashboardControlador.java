package Controlador;

import Modelo.DashboardDAO;
import Vista.Prim_menu;
import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;


// Coordina la pantalla principal del sistema, mostrando los totales importantes, la lista de movimientos recientes y la gráfica mensual.
public class DashboardControlador {

    private Prim_menu vista;
    private DashboardDAO dao;

    private static boolean autoEnlaceRegistrado = false;
    private static final Set<Prim_menu> vistasControladas =
            Collections.newSetFromMap(new WeakHashMap<>());

    static {
        activarAutoEnlace();
    }
    
   

    // Se asegura de que la pantalla principal cargue sus datos automáticamente cada vez que se abre.
    public static void activarAutoEnlace() {
        if (autoEnlaceRegistrado) {
            return;
        }
        autoEnlaceRegistrado = true;
        Toolkit.getDefaultToolkit().addAWTEventListener((AWTEvent event) -> {
            if (event.getID() == WindowEvent.WINDOW_OPENED || event.getID() == WindowEvent.WINDOW_ACTIVATED) {
                Object source = event.getSource();
                if (source instanceof Prim_menu) {
                    Prim_menu pm = (Prim_menu) source;
                    if (!vistasControladas.contains(pm)) {
                        new DashboardControlador(pm);
                    }
                }
            }
        }, AWTEvent.WINDOW_EVENT_MASK);
    }

    // Prepara la pantalla principal y muestra de inmediato los números, la lista de préstamos y la gráfica.
    public DashboardControlador(Prim_menu vista, DashboardDAO dao) {
        this.vista = (vista != null) ? vista : new Prim_menu();
        this.dao = (dao != null) ? dao : new DashboardDAO();

        vistasControladas.add(this.vista);

        // Configura la ventana para que al cerrarla no se apague todo el programa
        this.vista.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        // Muestra toda la información en la pantalla
        cargarIndicadores();
        cargarTablaActividad();
        cargarGrafico();
    }

    // Prepara la pantalla principal usando la configuración habitual del sistema.
    public DashboardControlador(Prim_menu vista) {
        this(vista, new DashboardDAO());
    }

    // Muestra en las tarjetas de la pantalla el total de libros existentes, los préstamos activos y los libros pendientes de devolución.
    public void cargarIndicadores() {
        if (this.vista == null || this.dao == null) {
            return;
        }

        int totalLibros = dao.contarTotalLibros();
        int prestamosActivos = dao.contarPrestamosActivos();
        int devolucionesPendientes = dao.contarDevolucionesPendientes();

        JLabel lblTotal = getLblTotalLibros();
        if (lblTotal != null) {
            lblTotal.setText(String.valueOf(totalLibros));
        }

        JLabel lblPrestamos = getLblPrestamosActivos();
        if (lblPrestamos != null) {
            lblPrestamos.setText(String.valueOf(prestamosActivos));
        }

        JLabel lblDevoluciones = getLblDevolucionesPendientes();
        if (lblDevoluciones != null) {
            lblDevoluciones.setText(String.valueOf(devolucionesPendientes));
        }
    }

    // Muestra en pantalla la lista con los préstamos de libros más recientes.
    public void cargarTablaActividad() {
        if (this.vista == null || this.dao == null) {
            return;
        }

        JTable tabla = getTablaActividad();
        if (tabla != null) {
            DefaultTableModel modelo = dao.obtenerActividadReciente();
            if (modelo != null) {
                tabla.setModel(modelo);
            }
        }
    }

    // Dibuja la gráfica de barras que muestra cuántos libros se han prestado en cada mes del año.
    public void cargarGrafico() {
        java.util.Map<String, Integer> datosMes = dao.obtenerPrestamosPorMes();

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        if (datosMes != null) {
            for (java.util.Map.Entry<String, Integer> entry : datosMes.entrySet()) {
                dataset.addValue(entry.getValue(), "Préstamos", entry.getKey());
            }
        }

        JFreeChart chart = ChartFactory.createBarChart(
                "Préstamos por Mes",
                "Mes",
                "Cantidad",
                dataset,
                org.jfree.chart.plot.PlotOrientation.VERTICAL,
                false,
                true,
                false
        );

        ChartPanel chartPanel = new ChartPanel(chart);

        vista.getPanelGrafico().removeAll();
        vista.getPanelGrafico().add(chartPanel, java.awt.BorderLayout.CENTER);
        vista.getPanelGrafico().revalidate();
        vista.getPanelGrafico().repaint();
    }

    private JLabel getLblTotalLibros() {
        return obtenerComponente(vista, JLabel.class,
                new String[]{"getLblTotalLibros", "getJLabel14"},
                new String[]{"lblTotalLibros", "jLabel14"});
    }

    private JLabel getLblPrestamosActivos() {
        return obtenerComponente(vista, JLabel.class,
                new String[]{"getLblPrestamosActivos", "getJLabel15"},
                new String[]{"lblPrestamosActivos", "jLabel15"});
    }

    private JLabel getLblDevolucionesPendientes() {
        return obtenerComponente(vista, JLabel.class,
                new String[]{"getLblDevolucionesPendientes", "getJLabel16"},
                new String[]{"lblDevolucionesPendientes", "jLabel16"});
    }

    private JTable getTablaActividad() {
        return obtenerComponente(vista, JTable.class,
                new String[]{"getTablaActividad", "getJTable1", "getTabla"},
                new String[]{"tablaActividad", "jTable1"});
    }

    private JPanel getPanelGrafico() {
        return obtenerComponente(vista, JPanel.class,
                new String[]{"getPanelGrafico", "getJPanel4", "getPanel"},
                new String[]{"panelGrafico", "jPanel4"});
    }

    @SuppressWarnings("unchecked")
    private <T> T obtenerComponente(Object vistaObj, Class<T> tipo, String[] nombresGetters, String[] nombresCampos) {
        if (vistaObj == null) {
            return null;
        }
        for (String nombreMetodo : nombresGetters) {
            try {
                Method m = vistaObj.getClass().getMethod(nombreMetodo);
                Object resultado = m.invoke(vistaObj);
                if (tipo.isInstance(resultado)) {
                    return (T) resultado;
                }
            } catch (Exception ignored) {
            }
        }
        for (String nombreCampo : nombresCampos) {
            try {
                Field f = vistaObj.getClass().getDeclaredField(nombreCampo);
                f.setAccessible(true);
                Object resultado = f.get(vistaObj);
                if (tipo.isInstance(resultado)) {
                    return (T) resultado;
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }
}
