package Controlador;

import Modelo.DetallePrestamo;
import Modelo.DetallePrestamoDAO;
import Modelo.Estudiante;
import Modelo.EstudianteDAO;
import Modelo.Libro;
import Modelo.LibroDAO;
import Modelo.Prestamo;
import Modelo.PrestamoDAO;
import Vista.Prestamos;
import java.awt.AWTEvent;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

// Coordina la pantalla de préstamos, permitiendo armar la lista de libros solicitados por un estudiante y registrar la salida.
public class PrestamoControlador implements ActionListener {

    private Prestamos vista;
    private Prestamo modeloPrestamo;
    private DetallePrestamo modeloDetalle;
    private PrestamoDAO daoPrestamo;
    private DetallePrestamoDAO daoDetalle;
    private LibroDAO daoLibro;
    private EstudianteDAO daoEstudiante;

    private List<Libro> listaLibrosDisponibles = new ArrayList<>();
    private List<Estudiante> listaEstudiantes = new ArrayList<>();

    private static boolean autoEnlaceRegistrado = false;
    private static final Set<Prestamos> vistasControladas =
            Collections.newSetFromMap(new WeakHashMap<>());

    static {
        activarAutoEnlace();
    }

    // Conecta la pantalla de préstamos automáticamente en cuanto se abre en el sistema.
    public static void activarAutoEnlace() {
        if (autoEnlaceRegistrado) {
            return;
        }
        autoEnlaceRegistrado = true;
        Toolkit.getDefaultToolkit().addAWTEventListener((AWTEvent event) -> {
            if (event.getID() == WindowEvent.WINDOW_OPENED || event.getID() == WindowEvent.WINDOW_ACTIVATED) {
                Object source = event.getSource();
                if (source instanceof Prestamos) {
                    Prestamos vp = (Prestamos) source;
                    if (!vistasControladas.contains(vp)) {
                        new PrestamoControlador(vp);
                    }
                }
            }
        }, AWTEvent.WINDOW_EVENT_MASK);
    }

    // Prepara la pantalla de préstamos, llena las listas de estudiantes y libros disponibles, y alista la tabla.
    public PrestamoControlador(Prestamos vista, Prestamo modeloPrestamo, DetallePrestamo modeloDetalle, PrestamoDAO daoPrestamo, DetallePrestamoDAO daoDetalle) {
        this.vista = (vista != null) ? vista : new Prestamos();
        this.modeloPrestamo = (modeloPrestamo != null) ? modeloPrestamo : new Prestamo();
        this.modeloDetalle = (modeloDetalle != null) ? modeloDetalle : new DetallePrestamo();
        this.daoPrestamo = (daoPrestamo != null) ? daoPrestamo : new PrestamoDAO();
        this.daoDetalle = (daoDetalle != null) ? daoDetalle : new DetallePrestamoDAO();
        this.daoLibro = new LibroDAO();
        this.daoEstudiante = new EstudianteDAO();

        vistasControladas.add(this.vista);

        this.vista.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        inicializarTablaPrestamos();
        cargarCombos();
        registrarEventos();
    }

    // Prepara la pantalla de préstamos con sus accesos a datos.
    public PrestamoControlador(Prestamos vista, PrestamoDAO daoPrestamo, DetallePrestamoDAO daoDetalle) {
        this(vista, new Prestamo(), new DetallePrestamo(), daoPrestamo, daoDetalle);
    }

    // Prepara la pantalla de préstamos con su configuración habitual.
    public PrestamoControlador(Prestamos vista) {
        this(vista, new Prestamo(), new DetallePrestamo(), new PrestamoDAO(), new DetallePrestamoDAO());
    }

    // Conecta los botones de la pantalla para responder a los clics del usuario.
    private void registrarEventos() {
        if (this.vista != null) {
            JButton btnAgregar = this.vista.getBtnAgregar();
            if (btnAgregar != null) {
                btnAgregar.removeActionListener(this);
                btnAgregar.addActionListener(this);
            }

            JButton btnEliminar = this.vista.getBtnEliminar();
            if (btnEliminar != null) {
                btnEliminar.removeActionListener(this);
                btnEliminar.addActionListener(this);
            }

            JButton btnPrestar = this.vista.getBtnPrestar();
            if (btnPrestar != null) {
                btnPrestar.removeActionListener(this);
                btnPrestar.addActionListener(this);
            }
        }
    }

    // Prepara los encabezados de la lista de libros a prestar.
    public void inicializarTablaPrestamos() {
        if (this.vista == null) {
            return;
        }

        JTable tabla = this.vista.getTablaPrestamos();
        if (tabla == null) {
            return;
        }

        String[] columnas = {"Cod de Libro", "Libro", "Autor", "Categoría", "Fecha Préstamo", "Fecha Devolución"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla.setModel(modeloTabla);
    }

    // Llena las listas desplegables con los libros disponibles y los estudiantes registrados.
    public void cargarCombos() {
        if (this.vista == null) {
            return;
        }

        this.listaLibrosDisponibles = daoLibro.listar();
        int totalLibros = (this.listaLibrosDisponibles != null) ? this.listaLibrosDisponibles.size() : 0;
        System.out.println("Libros encontrados en BD: " + totalLibros);

        JComboBox<String> cmbLibro = this.vista.getCmbLibro();
        if (cmbLibro != null) {
            cmbLibro.removeAllItems();
            if (this.listaLibrosDisponibles != null && !this.listaLibrosDisponibles.isEmpty()) {
                for (Libro libro : this.listaLibrosDisponibles) {
                    cmbLibro.addItem(libro.getTitulo());
                }
            }
        }

        this.listaEstudiantes = daoEstudiante.listar();
        int totalEstudiantes = (this.listaEstudiantes != null) ? this.listaEstudiantes.size() : 0;
        System.out.println("Estudiantes encontrados en BD: " + totalEstudiantes);

        JComboBox<String> cmbEstudiante = this.vista.getCmbEstudiante();
        if (cmbEstudiante != null) {
            cmbEstudiante.removeAllItems();
            if (this.listaEstudiantes != null && !this.listaEstudiantes.isEmpty()) {
                for (Estudiante estudiante : this.listaEstudiantes) {
                    cmbEstudiante.addItem(estudiante.getNombres() + " " + estudiante.getApellidos());
                }
            }
        }

        if (totalLibros == 0 || totalEstudiantes == 0) {
            JOptionPane.showMessageDialog(
                    vista,
                    "No hay datos en la base de datos para cargar.",
                    "Diagnóstico de Base de Datos",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    // Añade el libro elegido a la lista de préstamo y calcula la fecha máxima de entrega.
    public void agregarLibroATabla() {
        if (this.vista == null) {
            return;
        }

        JComboBox<String> cmbLibro = this.vista.getCmbLibro();
        if (cmbLibro == null || cmbLibro.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(
                    vista,
                    "Por favor, seleccione un libro para añadir al préstamo.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int indexLibro = cmbLibro.getSelectedIndex();
        Libro libroSeleccionado = null;

        if (indexLibro >= 0 && this.listaLibrosDisponibles != null && indexLibro < this.listaLibrosDisponibles.size()) {
            libroSeleccionado = this.listaLibrosDisponibles.get(indexLibro);
        } else if (cmbLibro.getSelectedItem() != null) {
            String tituloSeleccionado = cmbLibro.getSelectedItem().toString();
            for (Libro l : this.listaLibrosDisponibles) {
                if (l.getTitulo() != null && l.getTitulo().equals(tituloSeleccionado)) {
                    libroSeleccionado = l;
                    break;
                }
            }
        }

        if (libroSeleccionado == null) {
            return;
        }

        JTable tabla = this.vista.getTablaPrestamos();
        if (tabla == null) {
            return;
        }

        DefaultTableModel modeloTabla = (DefaultTableModel) tabla.getModel();

        int codLibro = libroSeleccionado.getCod_libro();
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            try {
                Object val = modeloTabla.getValueAt(i, 0);
                if (val != null) {
                    int idExistente = Integer.parseInt(val.toString().trim());
                    if (idExistente == codLibro) {
                        JOptionPane.showMessageDialog(
                                vista,
                                "El libro \"" + libroSeleccionado.getLibro() + "\" ya está en la lista de préstamo.",
                                "Libro Duplicado",
                                JOptionPane.WARNING_MESSAGE
                        );
                        return;
                    }
                }
            } catch (Exception ignored) {
            }
        }

        LocalDate fechaPrestamo = LocalDate.now();
        LocalDate fechaDevolucion = fechaPrestamo.plusDays(15);

        Object[] fila = new Object[6];
        fila[0] = libroSeleccionado.getCod_libro();
        fila[1] = libroSeleccionado.getLibro();
        fila[2] = libroSeleccionado.getAutor();
        fila[3] = libroSeleccionado.getCategoria();
        fila[4] = fechaPrestamo.toString();
        fila[5] = fechaDevolucion.toString();

        modeloTabla.addRow(fila);

        if (modeloTabla.getRowCount() > 0) {
            JComboBox<String> cmbEstudiante = this.vista.getCmbEstudiante();
            if (cmbEstudiante != null) {
                cmbEstudiante.setEnabled(false);
            }
        }
    }

    // Quita el libro seleccionado de la lista de préstamo.
    public void eliminarLibroDeTabla() {
        if (this.vista == null) {
            return;
        }

        JTable tabla = this.vista.getTablaPrestamos();
        if (tabla == null) {
            return;
        }

        int filaSeleccionada = tabla.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(
                    vista,
                    "Por favor, seleccione un libro de la tabla para eliminarlo de la lista.",
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        DefaultTableModel modeloTabla = (DefaultTableModel) tabla.getModel();
        modeloTabla.removeRow(filaSeleccionada);

        if (modeloTabla.getRowCount() == 0) {
            JComboBox<String> cmbEstudiante = this.vista.getCmbEstudiante();
            if (cmbEstudiante != null) {
                cmbEstudiante.setEnabled(true);
            }
        }
    }

    // Revisa que el estudiante no deba libros, descuenta los ejemplares prestados y confirma la salida de los libros.
    public void realizarPrestamo() {
        if (this.vista == null) {
            return;
        }

        JTable tabla = this.vista.getTablaPrestamos();
        if (tabla == null) {
            return;
        }

        DefaultTableModel modeloTabla = (DefaultTableModel) tabla.getModel();
        int totalFilas = modeloTabla.getRowCount();

        if (totalFilas == 0) {
            JOptionPane.showMessageDialog(
                    vista,
                    "Debe agregar al menos un libro a la lista para procesar el préstamo.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        JComboBox<String> cmbEstudiante = this.vista.getCmbEstudiante();
        int indexEstudiante = (cmbEstudiante != null) ? cmbEstudiante.getSelectedIndex() : -1;

        if (indexEstudiante < 0 || this.listaEstudiantes == null || indexEstudiante >= this.listaEstudiantes.size()) {
            JOptionPane.showMessageDialog(
                    vista,
                    "Por favor, seleccione un estudiante válido.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        Estudiante estudianteSeleccionado = this.listaEstudiantes.get(indexEstudiante);
        int idEstudiante = estudianteSeleccionado.getCodigo();

        LocalDate fechaPrestamo = LocalDate.now();
        LocalDate fechaDevolucion = fechaPrestamo.plusDays(15);

        Prestamo nuevoPrestamo = new Prestamo(idEstudiante, fechaPrestamo, fechaDevolucion);
        List<DetallePrestamo> listaDetalles = new ArrayList<>();

        for (int i = 0; i < totalFilas; i++) {
            try {
                Object valCod = modeloTabla.getValueAt(i, 0);
                if (valCod != null) {
                    int codLibro = Integer.parseInt(valCod.toString().trim());
                    DetallePrestamo dp = new DetallePrestamo();
                    dp.setCod_libro(codLibro);
                    dp.setCantidad(1);
                    listaDetalles.add(dp);
                }
            } catch (Exception ex) {
                System.err.println("Error al leer fila de préstamo: " + ex.getMessage());
            }
        }

        if (listaDetalles.isEmpty()) {
            JOptionPane.showMessageDialog(
                    vista,
                    "No se encontraron libros válidos en la lista.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        boolean exito = daoPrestamo.registrarPrestamo(nuevoPrestamo, listaDetalles);

        if (exito) {
            modeloTabla.setRowCount(0);

            if (cmbEstudiante != null) {
                cmbEstudiante.setEnabled(true);
            }

            JOptionPane.showMessageDialog(
                    vista,
                    "Su prestamo se ha realizado correctamente."
            );

            cargarCombos();
        } else {
            String errorMsg = daoPrestamo.getUltimoError();
            if (errorMsg != null && errorMsg.contains("Bloqueo")) {
                JOptionPane.showMessageDialog(
                        vista,
                        errorMsg,
                        "Préstamo Restringido",
                        JOptionPane.WARNING_MESSAGE
                );
            } else {
                JOptionPane.showMessageDialog(
                        vista,
                        (errorMsg != null && !errorMsg.trim().isEmpty()) ? errorMsg : "Ocurrió un error al procesar el préstamo en la base de datos. Verifique el stock disponible.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (this.vista == null) {
            return;
        }

        Object source = e.getSource();

        if (source == this.vista.getBtnAgregar()) {
            agregarLibroATabla();
        } else if (source == this.vista.getBtnEliminar()) {
            eliminarLibroDeTabla();
        } else if (source == this.vista.getBtnPrestar()) {
            realizarPrestamo();
        }
    }
}
