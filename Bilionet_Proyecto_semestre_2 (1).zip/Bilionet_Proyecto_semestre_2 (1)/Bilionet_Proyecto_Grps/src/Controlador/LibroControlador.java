package Controlador;

import Modelo.Autor;
import Modelo.AutorDAO;
import Modelo.Categoria;
import Modelo.CategoriaDAO;
import Modelo.Libro;
import Modelo.LibroDAO;
import Vista.Gestion_libros;
import Vista.Gestion_prestamos_2;
import java.awt.AWTEvent;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

// Coordina las pantallas de catálogo de libros, permitiendo ver las existencias, agregar nuevos títulos y editar o dar de baja libros.
public class LibroControlador implements ActionListener {

    private Gestion_prestamos_2 vistaPrestamos;
    private Gestion_libros vistaGestionLibros;
    private Libro modelo;
    private LibroDAO dao;
    private AutorDAO autorDao;
    private CategoriaDAO categoriaDao;

    // Indica si se está registrando un libro nuevo o modificando uno existente
    private boolean modoActualizar = false;

    private static boolean autoEnlaceRegistrado = false;
    private static final Set<Gestion_prestamos_2> vistasControladas =
            Collections.newSetFromMap(new WeakHashMap<>());

    static {
        activarAutoEnlace();
    }

    // Conecta la pantalla del catálogo de libros automáticamente al abrirse.
    public static void activarAutoEnlace() {
        if (autoEnlaceRegistrado) {
            return;
        }
        autoEnlaceRegistrado = true;
        Toolkit.getDefaultToolkit().addAWTEventListener((AWTEvent event) -> {
            if (event.getID() == WindowEvent.WINDOW_OPENED || event.getID() == WindowEvent.WINDOW_ACTIVATED) {
                Object source = event.getSource();
                if (source instanceof Gestion_prestamos_2) {
                    Gestion_prestamos_2 vp = (Gestion_prestamos_2) source;
                    if (!vistasControladas.contains(vp) && !tieneControladorAsignado(vp)) {
                        new LibroControlador(vp, new Gestion_libros(), new Libro(), new LibroDAO());
                    }
                }
            }
        }, AWTEvent.WINDOW_EVENT_MASK);
    }

    private static boolean tieneControladorAsignado(Gestion_prestamos_2 vp) {
        if (vp == null || vp.getBtnCrear() == null) {
            return false;
        }
        for (ActionListener al : vp.getBtnCrear().getActionListeners()) {
            if (al instanceof LibroControlador) {
                return true;
            }
        }
        return false;
    }

    // Prepara las pantallas de libros, carga las listas desplegables de autores y categorías, y muestra el catálogo completo.
    public LibroControlador(Gestion_prestamos_2 vistaPrestamos, Gestion_libros vistaGestionLibros, Libro modelo, LibroDAO dao) {
        this.vistaPrestamos = vistaPrestamos;
        this.vistaGestionLibros = (vistaGestionLibros != null) ? vistaGestionLibros : new Gestion_libros();
        this.modelo = (modelo != null) ? modelo : new Libro();
        this.dao = (dao != null) ? dao : new LibroDAO();
        this.autorDao = new AutorDAO();
        this.categoriaDao = new CategoriaDAO();

        if (this.vistaPrestamos != null) {
            vistasControladas.add(this.vistaPrestamos);
            this.vistaPrestamos.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        }

        if (this.vistaGestionLibros != null) {
            this.vistaGestionLibros.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        }

        registrarEventos();
        cargarCombos();
        cargarTabla();
    }

    // Prepara las pantallas de libros.
    public LibroControlador(Gestion_prestamos_2 vistaPrestamos, Gestion_libros vistaGestionLibros, LibroDAO dao) {
        this(vistaPrestamos, vistaGestionLibros, new Libro(), dao);
    }

    // Prepara las pantallas de libros con su configuración habitual.
    public LibroControlador(Gestion_prestamos_2 vistaPrestamos, Gestion_libros vistaGestionLibros) {
        this(vistaPrestamos, vistaGestionLibros, new Libro(), new LibroDAO());
    }

    // Prepara las pantallas de libros a partir de la vista principal.
    public LibroControlador(Gestion_prestamos_2 vistaPrestamos, Libro modelo, LibroDAO dao) {
        this(vistaPrestamos, new Gestion_libros(), modelo, dao);
    }

    // Prepara las pantallas de libros con acceso a datos.
    public LibroControlador(Gestion_prestamos_2 vistaPrestamos, LibroDAO dao) {
        this(vistaPrestamos, new Gestion_libros(), new Libro(), dao);
    }

    // Prepara la pantalla de libros a partir de la vista principal.
    public LibroControlador(Gestion_prestamos_2 vistaPrestamos) {
        this(vistaPrestamos, new Gestion_libros(), new Libro(), new LibroDAO());
    }

    // Conecta los botones de las pantallas para que respondan a los clics del usuario.
    private void registrarEventos() {
        // Botones de la vista principal: Gestion_prestamos_2
        if (this.vistaPrestamos != null) {
            if (this.vistaPrestamos.getBtnCrear() != null) {
                this.vistaPrestamos.getBtnCrear().removeActionListener(this);
                this.vistaPrestamos.getBtnCrear().addActionListener(this);
            }
            if (this.vistaPrestamos.getBtnActualizar() != null) {
                this.vistaPrestamos.getBtnActualizar().removeActionListener(this);
                this.vistaPrestamos.getBtnActualizar().addActionListener(this);
            }
            if (this.vistaPrestamos.getBtnEliminar() != null) {
                this.vistaPrestamos.getBtnEliminar().removeActionListener(this);
                this.vistaPrestamos.getBtnEliminar().addActionListener(this);
            }
            if (this.vistaPrestamos.getBtnBuscar() != null) {
                this.vistaPrestamos.getBtnBuscar().removeActionListener(this);
                this.vistaPrestamos.getBtnBuscar().addActionListener(this);
            }
            if (this.vistaPrestamos.getBtnPrestar() != null) {
                this.vistaPrestamos.getBtnPrestar().removeActionListener(this);
                this.vistaPrestamos.getBtnPrestar().addActionListener(this);
            }
            if (this.vistaPrestamos.getTxtBuscar() != null) {
                this.vistaPrestamos.getTxtBuscar().removeActionListener(this);
                this.vistaPrestamos.getTxtBuscar().addActionListener(this);
            }
        }

        // Botón Agregar de la vista formulario: Gestion_libros
        if (this.vistaGestionLibros != null) {
            JButton btnAgregar = getBtnAgregar();
            if (btnAgregar != null) {
                btnAgregar.removeActionListener(this);
                btnAgregar.addActionListener(this);
            }
        }
    }

    // Llena las listas desplegables con las opciones de categorías y autores disponibles.
    public void cargarCombos() {
        if (this.vistaGestionLibros == null) {
            return;
        }

        JComboBox<String> cmbCategoria = getCmbCategoria();
        if (cmbCategoria != null) {
            cmbCategoria.removeAllItems();
            List<Categoria> categorias = categoriaDao.listar();
            if (categorias != null) {
                for (Categoria c : categorias) {
                    cmbCategoria.addItem(c.getNombre_categoria());
                }
            }
        }

        JComboBox<String> cmbAutor = getCmbAutor();
        if (cmbAutor != null) {
            cmbAutor.removeAllItems();
            List<Autor> autores = autorDao.listar();
            if (autores != null) {
                for (Autor a : autores) {
                    cmbAutor.addItem(a.getNombreCompleto());
                }
            }
        }
    }

    // Muestra en la tabla la lista actualizada con todos los libros y sus existencias.
    public void cargarTabla() {
        if (vistaPrestamos == null || vistaPrestamos.getTablaLibros() == null) {
            return;
        }

        String[] columnas = {"Cod_libro", "Libro", "Autor", "Edicion", "Categoria", "Cantidad"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        List<Libro> lista = dao.listar();
        if (lista != null) {
            for (Libro l : lista) {
                Object[] fila = new Object[6];
                fila[0] = l.getCod_libro();
                fila[1] = l.getLibro();
                fila[2] = l.getAutor();
                fila[3] = l.getEdicion();
                fila[4] = l.getCategoria();
                fila[5] = l.getCantidad();
                modeloTabla.addRow(fila);
            }
        }

        vistaPrestamos.getTablaLibros().setModel(modeloTabla);
    }

    // Abre la ventana con los campos limpios y el siguiente código asignado para registrar un libro nuevo.
    public void abrirVentanaCrear() {
        if (this.vistaGestionLibros == null) {
            this.vistaGestionLibros = new Gestion_libros();
            this.vistaGestionLibros.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
            registrarEventos();
        }

        this.modoActualizar = false;
        cargarCombos();

        if (getTxtTitulo() != null) {
            getTxtTitulo().setText("");
        }
        if (getTxtEditorial() != null) {
            getTxtEditorial().setText("");
        }
        if (getTxtCantidad() != null) {
            getTxtCantidad().setText("");
        }

        if (getCmbCategoria() != null && getCmbCategoria().getItemCount() > 0) {
            getCmbCategoria().setSelectedIndex(0);
        }
        if (getCmbAutor() != null && getCmbAutor().getItemCount() > 0) {
            getCmbAutor().setSelectedIndex(0);
        }

        int siguienteId = dao.obtenerSiguienteId();
        if (getTxtCodigo() != null) {
            getTxtCodigo().setEditable(false);
            getTxtCodigo().setText(String.valueOf(siguienteId));
        }

        this.vistaGestionLibros.setLocationRelativeTo(null);
        this.vistaGestionLibros.setVisible(true);
        this.vistaGestionLibros.toFront();
    }

    // Abre la ventana cargando los datos del libro seleccionado para poder modificarlos.
    public void abrirVentanaActualizar() {
        if (vistaPrestamos == null || vistaPrestamos.getTablaLibros() == null) {
            return;
        }

        JTable tabla = vistaPrestamos.getTablaLibros();
        int fila = tabla.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                    vistaPrestamos,
                    "Por favor, seleccione un libro de la tabla para actualizar.",
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        String codigo = String.valueOf(tabla.getValueAt(fila, 0));
        String titulo = String.valueOf(tabla.getValueAt(fila, 1));
        String autor = String.valueOf(tabla.getValueAt(fila, 2));
        String editorial = String.valueOf(tabla.getValueAt(fila, 3));
        String categoria = String.valueOf(tabla.getValueAt(fila, 4));
        String cantidad = String.valueOf(tabla.getValueAt(fila, 5));

        if (this.vistaGestionLibros == null) {
            this.vistaGestionLibros = new Gestion_libros();
            this.vistaGestionLibros.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
            registrarEventos();
        }

        this.modoActualizar = true;
        cargarCombos();

        if (getTxtCodigo() != null) {
            getTxtCodigo().setText(codigo);
            getTxtCodigo().setEditable(false);
        }
        if (getTxtTitulo() != null) {
            getTxtTitulo().setText(titulo);
        }
        if (getTxtEditorial() != null) {
            getTxtEditorial().setText(editorial);
        }
        if (getTxtCantidad() != null) {
            getTxtCantidad().setText(cantidad);
        }
        if (getCmbCategoria() != null) {
            getCmbCategoria().setSelectedItem(categoria);
        }
        if (getCmbAutor() != null) {
            getCmbAutor().setSelectedItem(autor);
        }

        this.vistaGestionLibros.setLocationRelativeTo(null);
        this.vistaGestionLibros.setVisible(true);
        this.vistaGestionLibros.toFront();
    }

    // Revisa que los datos del libro estén completos y los guarda o actualiza en el catálogo.
    public void guardarLibro() {
        if (this.vistaGestionLibros == null) {
            return;
        }

        String codigoStr = (getTxtCodigo() != null) ? getTxtCodigo().getText().trim() : "";
        String titulo = (getTxtTitulo() != null) ? getTxtTitulo().getText().trim() : "";
        String editorial = (getTxtEditorial() != null) ? getTxtEditorial().getText().trim() : "";
        String cantidadStr = (getTxtCantidad() != null) ? getTxtCantidad().getText().trim() : "";
        String nombreCategoria = (getCmbCategoria() != null && getCmbCategoria().getSelectedItem() != null)
                ? getCmbCategoria().getSelectedItem().toString().trim() : "";
        String nombreAutor = (getCmbAutor() != null && getCmbAutor().getSelectedItem() != null)
                ? getCmbAutor().getSelectedItem().toString().trim() : "";

        if (titulo.isEmpty() || editorial.isEmpty() || cantidadStr.isEmpty() || nombreCategoria.isEmpty() || nombreAutor.isEmpty()) {
            JOptionPane.showMessageDialog(
                    vistaGestionLibros,
                    "Por favor, complete todos los campos del formulario.",
                    "Campos Vacíos",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int cantidad;
        try {
            cantidad = Integer.parseInt(cantidadStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                    vistaGestionLibros,
                    "La cantidad de copias debe ser un número entero válido.",
                    "Formato Inválido",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int idCategoria = obtenerIdCategoriaPorNombre(nombreCategoria);
        int idAutor = obtenerIdAutorPorNombre(nombreAutor);

        if (idCategoria == -1 || idAutor == -1) {
            JOptionPane.showMessageDialog(
                    vistaGestionLibros,
                    "Seleccione un Autor y una Categoría válidos.",
                    "Error de Selección",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        Libro libro = new Libro();
        if (!codigoStr.isEmpty()) {
            try {
                libro.setCod_libro(Integer.parseInt(codigoStr));
            } catch (NumberFormatException ignored) {
            }
        }
        libro.setLibro(titulo);
        libro.setEdicion(editorial);
        libro.setId_categoria(idCategoria);
        libro.setId_autor(idAutor);
        libro.setCantidad(cantidad);

        if (modoActualizar) {
            boolean actualizado = dao.actualizar(libro);
            if (actualizado) {
                JOptionPane.showMessageDialog(
                        vistaGestionLibros,
                        "¡Libro actualizado correctamente!",
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE
                );
                cargarTabla();
                vistaGestionLibros.dispose();
            } else {
                JOptionPane.showMessageDialog(
                        vistaGestionLibros,
                        "Error al actualizar el libro en la base de datos.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        } else {
            boolean registrado = dao.registrar(libro);
            if (registrado) {
                JOptionPane.showMessageDialog(
                        vistaGestionLibros,
                        "¡Libro registrado correctamente!",
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE
                );
                cargarTabla();
                vistaGestionLibros.dispose();
            } else {
                JOptionPane.showMessageDialog(
                        vistaGestionLibros,
                        "Error al registrar el libro en la base de datos.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }

    private int obtenerIdCategoriaPorNombre(String nombre) {
        List<Categoria> categorias = categoriaDao.listar();
        if (categorias != null) {
            for (Categoria c : categorias) {
                if (c.getNombre_categoria() != null && c.getNombre_categoria().trim().equalsIgnoreCase(nombre.trim())) {
                    return c.getId_categoria();
                }
            }
        }
        return -1;
    }

    private int obtenerIdAutorPorNombre(String nombreCompleto) {
        List<Autor> autores = autorDao.listar();
        if (autores != null) {
            for (Autor a : autores) {
                if (a.getNombreCompleto().equalsIgnoreCase(nombreCompleto.trim())) {
                    return a.getId_autor();
                }
            }
        }
        return -1;
    }

    // Pide confirmación al usuario y retira el libro seleccionado del catálogo.
    public void eliminarLibro() {
        if (vistaPrestamos == null || vistaPrestamos.getTablaLibros() == null) {
            return;
        }

        JTable tabla = vistaPrestamos.getTablaLibros();
        int fila = tabla.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                    vistaPrestamos,
                    "Por favor, seleccione un libro de la tabla para eliminar.",
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = Integer.parseInt(tabla.getValueAt(fila, 0).toString());

        int confirmacion = JOptionPane.showConfirmDialog(
                vistaPrestamos,
                "¿Está seguro de que desea eliminar el libro con código " + id + "?",
                "Confirmación de Eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            boolean eliminado = dao.eliminar(id);
            if (eliminado) {
                JOptionPane.showMessageDialog(
                    vistaPrestamos,
                    "¡Libro eliminado correctamente!",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE
                );
                cargarTabla();
            } else {
                JOptionPane.showMessageDialog(
                    vistaPrestamos,
                    "Error al eliminar el libro de la base de datos.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }

    // Busca los libros que coincidan con el título, autor o categoría que escribimos.
    public void buscarLibros() {
        if (vistaPrestamos == null || vistaPrestamos.getTablaLibros() == null) {
            return;
        }

        String filtro = (vistaPrestamos.getTxtBuscar() != null)
                ? vistaPrestamos.getTxtBuscar().getText().trim() : "";

        if (filtro.isEmpty()) {
            cargarTabla();
            return;
        }

        String[] columnas = {"Cod_libro", "Libro", "Autor", "Edicion", "Categoria", "Cantidad"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        List<Libro> lista = dao.buscar(filtro);
        if (lista != null) {
            for (Libro l : lista) {
                Object[] fila = new Object[6];
                fila[0] = l.getCod_libro();
                fila[1] = l.getLibro();
                fila[2] = l.getAutor();
                fila[3] = l.getEdicion();
                fila[4] = l.getCategoria();
                fila[5] = l.getCantidad();
                modeloTabla.addRow(fila);
            }
        }

        vistaPrestamos.getTablaLibros().setModel(modeloTabla);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (vistaPrestamos != null && source == vistaPrestamos.getBtnPrestar()) {
            // Acción pendiente para flujo de préstamo desde catálogo
        } else if (vistaPrestamos != null && source == vistaPrestamos.getBtnCrear()) {
            abrirVentanaCrear();
        } else if (vistaPrestamos != null && source == vistaPrestamos.getBtnActualizar()) {
            abrirVentanaActualizar();
        } else if (vistaPrestamos != null && source == vistaPrestamos.getBtnEliminar()) {
            eliminarLibro();
        } else if (vistaPrestamos != null && (source == vistaPrestamos.getBtnBuscar() || source == vistaPrestamos.getTxtBuscar())) {
            buscarLibros();
        } else if (vistaGestionLibros != null && source == getBtnAgregar()) {
            guardarLibro();
        }
    }

    private JTextField getTxtTitulo() {
        return obtenerComponente(vistaGestionLibros, JTextField.class,
                new String[]{"getTxtTitulo", "getTxtNombreLibro", "getTxtLibro"},
                new String[]{"TxtTitulo", "TxtLibro", "txtTitulo", "txtLibro"});
    }

    private JTextField getTxtCodigo() {
        return obtenerComponente(vistaGestionLibros, JTextField.class,
                new String[]{"getTxtCodigo", "getTxtCodLibro", "getJTextField1"},
                new String[]{"TxtCodigo", "txtCodigo", "jTextField1"});
    }

    private JTextField getTxtEditorial() {
        return obtenerComponente(vistaGestionLibros, JTextField.class,
                new String[]{"getTxtEditorial", "getJtxtedit", "getTxtEdicion"},
                new String[]{"TxtEditorial", "jtxtedit", "txtEditorial", "TxtEdicion"});
    }

    private JComboBox<String> getCmbCategoria() {
        if (vistaGestionLibros != null && vistaGestionLibros.getCmbCategoria() != null) {
            return vistaGestionLibros.getCmbCategoria();
        }
        return obtenerComponente(vistaGestionLibros, JComboBox.class,
                new String[]{"getCmbCategoria"},
                new String[]{"cmbCategoria", "CmbCategoria"});
    }

    private JTextField getTxtCantidad() {
        return obtenerComponente(vistaGestionLibros, JTextField.class,
                new String[]{"getTxtCantidad", "getTxtcant", "getTxtCopias"},
                new String[]{"TxtCantidad", "txtcant", "txtCantidad"});
    }

    private JComboBox<String> getCmbAutor() {
        if (vistaGestionLibros != null && vistaGestionLibros.getCmbAutor() != null) {
            return vistaGestionLibros.getCmbAutor();
        }
        return obtenerComponente(vistaGestionLibros, JComboBox.class,
                new String[]{"getCmbAutor", "getTxtAutor"},
                new String[]{"TxtAutor", "cmbAutor", "CmbAutor"});
    }

    private JButton getBtnAgregar() {
        return obtenerComponente(vistaGestionLibros, JButton.class,
                new String[]{"getBtnAgregar", "getJButton4", "getBtnGuardar"},
                new String[]{"BtnAgregar", "btnAgregar", "jButton4"});
    }

    @SuppressWarnings("unchecked")
    private <T> T obtenerComponente(Object vistaObj, Class<T> tipo, String[] nombresGetters, String[] nombresCampos) {
        if (vistaObj == null) {
            return null;
        }
        for (String nombreMetodo : nombresGetters) {
            try {
                Method m = vistaObj.getClass().getMethod(nombreMetodo);
                Object resultado = m.invoke(vistaObj);
                if (tipo.isInstance(resultado)) {
                    return (T) resultado;
                }
            } catch (Exception ignored) {
            }
        }
        for (String nombreCampo : nombresCampos) {
            try {
                Field f = vistaObj.getClass().getDeclaredField(nombreCampo);
                f.setAccessible(true);
                Object resultado = f.get(vistaObj);
                if (tipo.isInstance(resultado)) {
                    return (T) resultado;
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }
}
