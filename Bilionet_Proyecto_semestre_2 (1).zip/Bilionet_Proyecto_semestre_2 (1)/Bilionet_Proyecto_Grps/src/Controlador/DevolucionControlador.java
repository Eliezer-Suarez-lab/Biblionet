package Controlador;

import Modelo.Devolucion;
import Modelo.DevolucionDAO;
import Vista.Devoluciones;
import java.awt.AWTEvent;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

// Administra la pantalla de devoluciones de libros, permitiendo buscar préstamos pendientes y recibir los libros entregados.
public class DevolucionControlador implements ActionListener {

    private Devoluciones vista;
    private Devolucion modelo;
    private DevolucionDAO dao;

    private static boolean autoEnlaceRegistrado = false;
    private static final Set<Devoluciones> vistasControladas =
            Collections.newSetFromMap(new WeakHashMap<>());

    static {
        activarAutoEnlace();
    }

    // Conecta la pantalla de devoluciones en cuanto se abre desde el menú principal.
    public static void activarAutoEnlace() {
        if (autoEnlaceRegistrado) {
            return;
        }
        autoEnlaceRegistrado = true;
        Toolkit.getDefaultToolkit().addAWTEventListener((AWTEvent event) -> {
            if (event.getID() == WindowEvent.WINDOW_OPENED || event.getID() == WindowEvent.WINDOW_ACTIVATED) {
                Object source = event.getSource();
                if (source instanceof Devoluciones) {
                    Devoluciones vd = (Devoluciones) source;
                    if (!vistasControladas.contains(vd)) {
                        new DevolucionControlador(vd);
                    }
                }
            }
        }, AWTEvent.WINDOW_EVENT_MASK);
    }

    // Prepara la pantalla de devoluciones y muestra la lista de libros pendientes de entrega.
    public DevolucionControlador(Devoluciones vista, Devolucion modelo, DevolucionDAO dao) {
        this.vista = (vista != null) ? vista : new Devoluciones();
        this.modelo = (modelo != null) ? modelo : new Devolucion();
        this.dao = (dao != null) ? dao : new DevolucionDAO();

        vistasControladas.add(this.vista);

        this.vista.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        inicializarTabla();
        cargarTabla(null);
        registrarEventos();
    }

    // Prepara la pantalla de devoluciones con la configuración indicada.
    public DevolucionControlador(Devoluciones vista, DevolucionDAO dao) {
        this(vista, new Devolucion(), dao);
    }

    // Prepara la pantalla de devoluciones con la configuración por defecto.
    public DevolucionControlador(Devoluciones vista) {
        this(vista, new Devolucion(), new DevolucionDAO());
    }

    // Prepara los encabezados de la lista de devoluciones.
    public void inicializarTabla() {
        JTable tabla = getTablaDevoluciones();
        if (tabla == null) {
            return;
        }

        String[] columnas = {"Cod_Prestamo", "Cod_Libro", "Estudiante", "Dias Restantes"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla.setModel(modeloTabla);
    }

    // Llena la lista en pantalla con todos los préstamos que aún no han sido devueltos.
    public void cargarTabla(String criterio) {
        JTable tabla = getTablaDevoluciones();
        if (tabla == null) {
            return;
        }

        tabla.setRowHeight(60);

        DefaultTableModel modeloTabla = (DefaultTableModel) tabla.getModel();
        modeloTabla.setRowCount(0);

        List<Devolucion> lista = dao.listarPendientes(criterio);
        if (lista != null) {
            for (Devolucion d : lista) {
                String cadenaLibros = d.getTituloLibro();
                String librosHtml = (cadenaLibros != null && !cadenaLibros.isEmpty())
                        ? "<html>" + cadenaLibros.replace(", ", "<br>") + "</html>"
                        : "";

                Object[] fila = new Object[4];
                fila[0] = d.getId_prestamo();
                fila[1] = librosHtml;
                fila[2] = d.getNombreEstudiante();
                fila[3] = d.getDiasRestantes();
                modeloTabla.addRow(fila);
            }
        }
    }

    // Conecta los botones y las teclas de la pantalla para responder a las acciones del usuario.
    private void registrarEventos() {
        if (this.vista == null) {
            return;
        }

        JButton btnBuscar = getBtnBuscar();
        if (btnBuscar != null) {
            btnBuscar.removeActionListener(this);
            btnBuscar.addActionListener(this);
        }

        JButton btnEntregar = getBtnEntregar();
        if (btnEntregar != null) {
            btnEntregar.removeActionListener(this);
            btnEntregar.addActionListener(this);
        }

        JTextField txtBuscar = getTxtBuscar();
        if (txtBuscar != null) {
            txtBuscar.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                        buscarPorId();
                    }
                }
            });
        }
    }

    // Busca los préstamos pendientes usando el número o código escrito.
    public void buscarPorId() {
        JTextField txtBuscar = getTxtBuscar();
        if (txtBuscar == null) {
            return;
        }

        String idTexto = txtBuscar.getText().trim();

        if (idTexto.isEmpty()) {
            JOptionPane.showMessageDialog(
                    vista,
                    "Por favor, ingrese el ID a buscar en el campo de texto.",
                    "Campo Vacío",
                    JOptionPane.WARNING_MESSAGE
            );
            txtBuscar.requestFocus();
            cargarTabla(null);
            return;
        }

        List<Devolucion> resultados = dao.buscarPorId(idTexto);

        JTable tabla = getTablaDevoluciones();
        if (tabla != null) {
            tabla.setRowHeight(60);
            DefaultTableModel modeloTabla = (DefaultTableModel) tabla.getModel();
            modeloTabla.setRowCount(0);

            if (resultados != null && !resultados.isEmpty()) {
                for (Devolucion d : resultados) {
                    String cadenaLibros = d.getTituloLibro();
                    String librosHtml = (cadenaLibros != null && !cadenaLibros.isEmpty())
                            ? "<html>" + cadenaLibros.replace(", ", "<br>") + "</html>"
                            : "";

                    Object[] fila = new Object[4];
                    fila[0] = d.getId_prestamo();
                    fila[1] = librosHtml;
                    fila[2] = d.getNombreEstudiante();
                    fila[3] = d.getDiasRestantes();
                    modeloTabla.addRow(fila);
                }
            } else {
                JOptionPane.showMessageDialog(
                        vista,
                        "No se encontró ningún préstamo pendiente asociado al ID: " + idTexto,
                        "Sin Resultados",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }
        }
    }

    // Inicia la búsqueda de préstamos pendientes.
    public void buscarPrestamos() {
        buscarPorId();
    }

    // Registra que el estudiante devolvió los libros y los regresa al inventario para que otros puedan pedirlos.
    public void entregarLibro() {
        JTable tabla = getTablaDevoluciones();
        if (tabla == null) {
            return;
        }

        int filaSeleccionada = tabla.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(
                    vista,
                    "Por favor, seleccione un registro de la tabla para registrar la devolución.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        DefaultTableModel modeloTabla = (DefaultTableModel) tabla.getModel();
        int idPrestamo = Integer.parseInt(modeloTabla.getValueAt(filaSeleccionada, 0).toString().trim());
        String libros = modeloTabla.getValueAt(filaSeleccionada, 1).toString();
        String estudiante = modeloTabla.getValueAt(filaSeleccionada, 2).toString();

        int confirmacion = JOptionPane.showConfirmDialog(
                vista,
                "¿Desea registrar la devolución de los libro(s): \"" + libros + "\" del estudiante \"" + estudiante + "\"?",
                "Confirmar Devolución",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        boolean exito = dao.registrarDevolucionPorPrestamo(idPrestamo);
        if (exito) {
            JOptionPane.showMessageDialog(
                    vista,
                    "Los libros han sido devueltos correctamente y se reintegraron al stock.",
                    "Devolución Exitosa",
                    JOptionPane.INFORMATION_MESSAGE
            );
            cargarTabla(null);
            JTextField txtBuscar = getTxtBuscar();
            if (txtBuscar != null) {
                txtBuscar.setText("");
            }
        } else {
            JOptionPane.showMessageDialog(
                    vista,
                    "Ocurrió un error al registrar la devolución en la base de datos.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == getBtnBuscar()) {
            buscarPorId();
        } else if (source == getBtnEntregar()) {
            entregarLibro();
        }
    }

    private JTextField getTxtBuscar() {
        return obtenerComponente(vista, JTextField.class,
                new String[]{"getTxtBuscar", "getTxtBuscarUsuario", "getTxtUsuario", "getJTextField2"},
                new String[]{"txtBuscar", "txtBuscarUsuario", "txtUsuario", "jTextField2"});
    }

    private JButton getBtnBuscar() {
        return obtenerComponente(vista, JButton.class,
                new String[]{"getBtnBuscar", "getJButtonBuscar", "getJButton1"},
                new String[]{"btnBuscar", "jButtonBuscar", "jButton1"});
    }

    private JButton getBtnEntregar() {
        return obtenerComponente(vista, JButton.class,
                new String[]{"getBtnEntregar", "getJButton4"},
                new String[]{"btnEntregar", "BtnEntregar", "jButton4"});
    }

    private JTable getTablaDevoluciones() {
        return obtenerComponente(vista, JTable.class,
                new String[]{"getTablaDevoluciones", "getTabla", "getJTable1"},
                new String[]{"tablaDevoluciones", "jTable1"});
    }

    @SuppressWarnings("unchecked")
    private <T> T obtenerComponente(Object vistaObj, Class<T> tipo, String[] nombresGetters, String[] nombresCampos) {
        if (vistaObj == null) {
            return null;
        }
        for (String nombreMetodo : nombresGetters) {
            try {
                Method m = vistaObj.getClass().getMethod(nombreMetodo);
                Object resultado = m.invoke(vistaObj);
                if (tipo.isInstance(resultado)) {
                    return (T) resultado;
                }
            } catch (Exception ignored) {
            }
        }
        for (String nombreCampo : nombresCampos) {
            try {
                Field f = vistaObj.getClass().getDeclaredField(nombreCampo);
                f.setAccessible(true);
                Object resultado = f.get(vistaObj);
                if (tipo.isInstance(resultado)) {
                    return (T) resultado;
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }
}
