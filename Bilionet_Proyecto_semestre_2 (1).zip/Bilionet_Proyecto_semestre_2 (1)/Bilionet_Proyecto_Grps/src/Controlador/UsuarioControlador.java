package Controlador;

import Conexion.Conexion;
import Modelo.Usuario;
import Modelo.UsuarioDAO;
import Vista.ActualizarU;
import Vista.Administrador;
import Vista.Bibliotecario;
import Vista.Crear_perfiles;
import Vista.Crear_usuario;
import Vista.Inicio;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

// Coordina el inicio de sesión y la administración de cuentas de usuario en el sistema.
public class UsuarioControlador implements ActionListener {

    private Crear_usuario vistaCrear;
    private Crear_perfiles vistaPerfiles;
    private ActualizarU vistaActualizar;
    private Inicio vistaInicio;

    private boolean vieneDeInicio = false;

    private JFrame contenedorActualizar;

    private Usuario modelo;
    private UsuarioDAO dao;

    // Prepara todas las pantallas relacionadas con los usuarios y el acceso al sistema.
    public UsuarioControlador(Inicio vistaInicio, Crear_usuario vistaCrear, Crear_perfiles vistaPerfiles, ActualizarU vistaActualizar, Usuario modelo, UsuarioDAO dao) {
        this.vistaInicio = vistaInicio;
        this.vistaCrear = vistaCrear;
        this.vistaPerfiles = vistaPerfiles;
        this.vistaActualizar = vistaActualizar;
        this.modelo = (modelo != null) ? modelo : new Usuario();
        this.dao = dao;

        LibroControlador.activarAutoEnlace();
        EstudianteControlador.activarAutoEnlace();

        if (this.vistaInicio != null) {
            enlazarVistaInicio();
        }
        if (this.vistaCrear != null) {
            enlazarVistaCrear();
        }
        if (this.vistaPerfiles != null) {
            enlazarVistaPerfiles();
        }
        if (this.vistaActualizar != null) {
            enlazarEventosActualizar();
        }
    }

    // Prepara las pantallas de usuario para el registro, la lista y la edición.
    public UsuarioControlador(Crear_usuario vistaCrear, Crear_perfiles vistaPerfiles, ActualizarU vistaActualizar, Usuario modelo, UsuarioDAO dao) {
        this(null, vistaCrear, vistaPerfiles, vistaActualizar, modelo, dao);
    }

    // Prepara la pantalla de entrada y comprobación de claves.
    public UsuarioControlador(Inicio vistaInicio, UsuarioDAO dao) {
        this(vistaInicio, null, null, null, null, dao);
        this.vieneDeInicio = true;
    }

    // Prepara el registro de una nueva cuenta cuando se abre desde la pantalla de entrada.
    public UsuarioControlador(Crear_usuario vistaCrear, Inicio vistaInicio, Usuario modelo, UsuarioDAO dao) {
        this(vistaCrear, null, null, modelo, dao);
        this.vistaInicio = vistaInicio;
        this.vieneDeInicio = true;
        enlazarVistaInicio();
    }

    // Prepara la pantalla de registro de usuarios.
    public UsuarioControlador(Crear_usuario vistaCrear, Usuario modelo, UsuarioDAO dao) {
        this(vistaCrear, null, null, modelo, dao);
    }

    // Prepara el registro de usuarios recordando desde qué pantalla se abrió.
    public UsuarioControlador(Crear_usuario vistaCrear, boolean vieneDeInicio, Usuario modelo, UsuarioDAO dao) {
        this(vistaCrear, null, null, modelo, dao);
        this.vieneDeInicio = vieneDeInicio;
    }

    // Prepara la tabla con la lista de usuarios.
    public UsuarioControlador(Crear_perfiles vistaPerfiles, UsuarioDAO dao) {
        this(null, vistaPerfiles, null, null, dao);
    }

    // Prepara la lista y la ventana de edición de usuarios.
    public UsuarioControlador(Crear_perfiles vistaPerfiles, ActualizarU vistaActualizar, UsuarioDAO dao) {
        this(null, vistaPerfiles, vistaActualizar, null, dao);
    }

    // Prepara la ventana de edición de usuarios.
    public UsuarioControlador(ActualizarU vistaActualizar, UsuarioDAO dao) {
        this(null, null, vistaActualizar, null, dao);
    }

    // Prepara la ventana de edición manteniendo la lista de usuarios al día.
    public UsuarioControlador(ActualizarU vistaActualizar, Crear_perfiles vistaPerfiles, UsuarioDAO dao) {
        this(null, vistaPerfiles, vistaActualizar, null, dao);
    }

    private void enlazarVistaCrear() {
        if (this.vistaCrear != null) {
            if (this.vistaCrear.getBtnCrear() != null) {
                this.vistaCrear.getBtnCrear().removeActionListener(this);
                this.vistaCrear.getBtnCrear().addActionListener(this);
            }
            if (this.vistaCrear.getBtnCerrar() != null) {
                this.vistaCrear.getBtnCerrar().removeActionListener(this);
                this.vistaCrear.getBtnCerrar().addActionListener(this);
            }
        }
    }

    private void enlazarVistaPerfiles() {
        if (this.vistaPerfiles != null) {
            if (this.vistaPerfiles.getBtnCrearPerfil() != null) {
                this.vistaPerfiles.getBtnCrearPerfil().removeActionListener(this);
                this.vistaPerfiles.getBtnCrearPerfil().addActionListener(this);
            }
            if (this.vistaPerfiles.getBtnActualizarPerfil() != null) {
                this.vistaPerfiles.getBtnActualizarPerfil().removeActionListener(this);
                this.vistaPerfiles.getBtnActualizarPerfil().addActionListener(this);
            }
            if (this.vistaPerfiles.getBtnEliminarPerfil() != null) {
                this.vistaPerfiles.getBtnEliminarPerfil().removeActionListener(this);
                this.vistaPerfiles.getBtnEliminarPerfil().addActionListener(this);
            }
            cargarTabla();
        }
    }

    private void enlazarEventosActualizar() {
        if (this.vistaActualizar != null) {
            if (this.vistaActualizar.getTxtCodigo() != null) {
                this.vistaActualizar.getTxtCodigo().setEditable(false);
            }
            if (this.vistaActualizar.getBtnGuardar() != null) {
                this.vistaActualizar.getBtnGuardar().removeActionListener(this);
                this.vistaActualizar.getBtnGuardar().addActionListener(this);
            }
            if (this.vistaActualizar.getBtnCancelar() != null) {
                this.vistaActualizar.getBtnCancelar().removeActionListener(this);
                this.vistaActualizar.getBtnCancelar().addActionListener(this);
            }
        }
    }

    private void enlazarVistaInicio() {
        if (this.vistaInicio != null) {
            if (this.vistaInicio.getBtnNuevo() != null) {
                this.vistaInicio.getBtnNuevo().removeActionListener(this);
                this.vistaInicio.getBtnNuevo().addActionListener(this);
            }
            if (this.vistaInicio.getBtnEntrar() != null) {
                this.vistaInicio.getBtnEntrar().removeActionListener(this);
                this.vistaInicio.getBtnEntrar().addActionListener(this);
            }
        }
    }

    private JTable obtenerTabla() {
        if (vistaPerfiles == null) {
            return null;
        }
        if (vistaPerfiles.getJTableUsuarios() != null) {
            return vistaPerfiles.getJTableUsuarios();
        }
        return vistaPerfiles.getTablaUsuarios();
    }

    // Muestra la ventana correspondiente en el centro de la pantalla.
    public void iniciar() {
        if (vistaInicio != null) {
            vistaInicio.setLocationRelativeTo(null);
            vistaInicio.setVisible(true);
        } else if (vistaCrear != null) {
            vistaCrear.setLocationRelativeTo(null);
            vistaCrear.setVisible(true);
        } else if (vistaPerfiles != null) {
            vistaPerfiles.setLocationRelativeTo(null);
            vistaPerfiles.setVisible(true);
            cargarTabla();
        } else if (vistaActualizar != null) {
            vistaActualizar.setVisible(true);
        }
    }

    // Responde a las acciones y clics de los botones en las pantallas de usuarios.
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        String command = (e.getActionCommand() != null) ? e.getActionCommand().trim() : "";

        if (vistaInicio != null && (source == vistaInicio.getBtnEntrar() || command.equalsIgnoreCase("Entrar"))) {
            iniciarSesion();
        } else if (vistaInicio != null && source == vistaInicio.getBtnNuevo()) {
            abrirCrearUsuarioDesdeInicio();
        } else if (vistaCrear != null && source == vistaCrear.getBtnCrear()) {
            guardarNuevoUsuario();
        } else if (vistaCrear != null && source == vistaCrear.getBtnCerrar()) {
            cerrarVistaCrear();
        } else if (vistaPerfiles != null && (source == vistaPerfiles.getBtnCrearPerfil() 
                || (vistaPerfiles.btnCrear != null && source == vistaPerfiles.btnCrear))) {
            abrirVentanaCrear();
        } else if (vistaPerfiles != null && (source == vistaPerfiles.getBtnEliminarPerfil() 
                || (vistaPerfiles.btnEliminar != null && source == vistaPerfiles.btnEliminar))) {
            eliminarUsuarioSeleccionado();
        } else if (vistaPerfiles != null && (source == vistaPerfiles.getBtnActualizarPerfil() 
                || (vistaPerfiles.btnActualizar != null && source == vistaPerfiles.btnActualizar)
                || command.equalsIgnoreCase("Actualizar"))) {
            abrirVentanaActualizar();
        } else if (vistaActualizar != null && (source == vistaActualizar.getBtnGuardar() || command.equalsIgnoreCase("Guardar"))) {
            guardarUsuarioActualizado();
        } else if (vistaActualizar != null && (source == vistaActualizar.getBtnCancelar() || command.equalsIgnoreCase("Cancelar"))) {
            cerrarVentanaActualizar();
        }
    }

    // Comprueba el correo y la contraseña, y da la bienvenida abriendo el menú de Administrador o Bibliotecario según corresponda.
    public void iniciarSesion() {
        if (vistaInicio == null) {
            return;
        }

        String correo = vistaInicio.getTxtCorreo().getText().trim();
        String contrasena = vistaInicio.getTxtContrasena().getText().trim();

        if (correo.isEmpty() || contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(
                    vistaInicio,
                    "Por favor, ingrese su correo y contraseña.",
                    "Campos Vacíos",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        Usuario usuarioLogueado = dao.autenticarUsuario(correo, contrasena);

        if (usuarioLogueado == null) {
            JOptionPane.showMessageDialog(
                    vistaInicio,
                    "Correo o contraseña incorrectos. Intente nuevamente.",
                    "Error de Autenticación",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        Conexion.establecerSesion(usuarioLogueado.getCorreo(), usuarioLogueado.getRol());

        if (usuarioLogueado.getRol() != null && usuarioLogueado.getRol().trim().equalsIgnoreCase("Administrador")) {
            JOptionPane.showMessageDialog(
                    vistaInicio,
                    "¡Bienvenido, " + usuarioLogueado.getNombres() + "!\nSesión iniciada con privilegios de Administrador.",
                    "Acceso Concedido",
                    JOptionPane.INFORMATION_MESSAGE
            );
            Administrador admin = new Administrador();
            admin.setLocationRelativeTo(null);
            admin.setVisible(true);
            vistaInicio.dispose();

        } else if (usuarioLogueado.getRol() != null && usuarioLogueado.getRol().trim().equalsIgnoreCase("Bibliotecario")) {
            JOptionPane.showMessageDialog(
                    vistaInicio,
                    "¡Bienvenido, " + usuarioLogueado.getNombres() + "!\nSesión iniciada con privilegios de Bibliotecario.",
                    "Acceso Concedido",
                    JOptionPane.INFORMATION_MESSAGE
            );
            Bibliotecario biblio = new Bibliotecario();
            biblio.setLocationRelativeTo(null);
            biblio.setVisible(true);
            vistaInicio.dispose();

        } else {
            JOptionPane.showMessageDialog(
                    vistaInicio,
                    "El usuario no tiene un rol válido asignado en el sistema.",
                    "Error de Rol",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // Abre la ventana para registrar una cuenta nueva desde la pantalla de entrada.
    public void abrirCrearUsuarioDesdeInicio() {
        this.vieneDeInicio = true;
        if (this.vistaCrear == null || !this.vistaCrear.isDisplayable()) {
            this.vistaCrear = new Crear_usuario();
            enlazarVistaCrear();
        }
        if (this.vistaInicio != null) {
            this.vistaInicio.setVisible(false);
        }
        vistaCrear.setLocationRelativeTo(null);
        vistaCrear.setVisible(true);
    }

    // Revisa que los datos personales y la contraseña estén completos y guarda la nueva cuenta en el sistema.
    private void guardarNuevoUsuario() {
        String nombres = vistaCrear.getTxtNombres().getText().trim();
        String apellidos = vistaCrear.getTxtApellidos().getText().trim();
        String correo = vistaCrear.getTxtCorreo().getText().trim();
        String contrasena = new String(vistaCrear.getTxtContrasena().getPassword()).trim();
        String rol = vistaCrear.getCmbRol().getSelectedItem() != null 
                ? vistaCrear.getCmbRol().getSelectedItem().toString().trim() 
                : "";

        if (nombres.isEmpty() || apellidos.isEmpty() || correo.isEmpty() || contrasena.isEmpty() || rol.isEmpty()) {
            JOptionPane.showMessageDialog(
                    vistaCrear,
                    "Por favor, complete todos los campos obligatorios.",
                    "Campos Vacíos",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        Usuario nuevoUsuario = new Usuario(nombres, apellidos, correo, contrasena, rol);
        this.modelo = nuevoUsuario;

        boolean insercionExitosa = dao.insertar(nuevoUsuario);

        if (insercionExitosa) {
            JOptionPane.showMessageDialog(
                    vistaCrear,
                    "¡Usuario registrado exitosamente!",
                    "Registro Exitoso",
                    JOptionPane.INFORMATION_MESSAGE
            );
            limpiarCampos();
            if (vistaPerfiles != null) {
                cargarTabla();
            }
        } else {
            JOptionPane.showMessageDialog(
                    vistaCrear,
                    "Error al registrar el usuario. Verifique los datos ingresados o la conexión con la base de datos.",
                    "Error al Registrar",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void limpiarCampos() {
        if (vistaCrear != null) {
            vistaCrear.getTxtNombres().setText("");
            vistaCrear.getTxtApellidos().setText("");
            vistaCrear.getTxtCorreo().setText("");
            vistaCrear.getTxtContrasena().setText("");
            if (vistaCrear.getCmbRol().getItemCount() > 0) {
                vistaCrear.getCmbRol().setSelectedIndex(0);
            }
        }
    }

    // Cierra la ventana de registro y regresa a la pantalla anterior.
    private void cerrarVistaCrear() {
        if (vistaCrear != null) {
            vistaCrear.dispose();
        }

        if (vieneDeInicio) {
            if (vistaInicio != null) {
                vistaInicio.setLocationRelativeTo(null);
                vistaInicio.setVisible(true);
            } else {
                Inicio inicio = new Inicio();
                inicio.setLocationRelativeTo(null);
                inicio.setVisible(true);
            }
        }
    }

    // Muestra en la tabla la lista de todas las personas con cuenta en el sistema.
    public void cargarTabla() {
        JTable tabla = obtenerTabla();
        if (tabla == null) {
            return;
        }

        String[] columnas = {"Código", "Nombres", "Apellidos", "Correo", "Contraseña", "Rol"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        List<Usuario> lista = dao.listar();
        if (lista != null) {
            for (Usuario u : lista) {
                Object[] fila = new Object[6];
                fila[0] = u.getId_usuario();
                fila[1] = u.getNombres();
                fila[2] = u.getApellidos();
                fila[3] = u.getCorreo();
                fila[4] = u.getContraseña();
                fila[5] = u.getRol();
                modeloTabla.addRow(fila);
            }
        }

        tabla.setModel(modeloTabla);
    }

    // Abre la ventana para registrar una nueva cuenta de usuario desde el menú principal.
    private void abrirVentanaCrear() {
        this.vieneDeInicio = false;
        if (this.vistaCrear == null || !this.vistaCrear.isDisplayable()) {
            this.vistaCrear = new Crear_usuario();
            enlazarVistaCrear();
        }
        vistaCrear.setLocationRelativeTo(null);
        vistaCrear.setVisible(true);
    }

    // Pide confirmación al usuario y elimina la cuenta seleccionada.
    private void eliminarUsuarioSeleccionado() {
        JTable tabla = obtenerTabla();
        if (tabla == null) {
            return;
        }

        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(
                    vistaPerfiles,
                    "Por favor, seleccione un usuario de la tabla para eliminar.",
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = Integer.parseInt(tabla.getValueAt(fila, 0).toString());

        int confirmacion = JOptionPane.showConfirmDialog(
                vistaPerfiles,
                "¿Está seguro de que desea eliminar al usuario con código " + id + "?",
                "Confirmación de Eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            boolean eliminado = dao.eliminar(id);
            if (eliminado) {
                JOptionPane.showMessageDialog(
                        vistaPerfiles,
                        "¡Usuario eliminado correctamente!",
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE
                );
                cargarTabla();
            } else {
                JOptionPane.showMessageDialog(
                        vistaPerfiles,
                        "Error al eliminar el usuario de la base de datos.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }

    // Abre la ventana cargando los datos de la cuenta elegida para poder editarlos.
    private void abrirVentanaActualizar() {
        JTable tabla = obtenerTabla();
        if (tabla == null) {
            return;
        }

        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(
                    vistaPerfiles,
                    "Por favor, seleccione un usuario de la tabla para actualizar.",
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        String codigo = String.valueOf(tabla.getValueAt(fila, 0));
        String nombres = String.valueOf(tabla.getValueAt(fila, 1));
        String apellidos = String.valueOf(tabla.getValueAt(fila, 2));
        String correo = String.valueOf(tabla.getValueAt(fila, 3));
        String contrasena = String.valueOf(tabla.getValueAt(fila, 4));
        String rol = String.valueOf(tabla.getValueAt(fila, 5));

        if (this.vistaActualizar == null) {
            this.vistaActualizar = new ActualizarU();
            enlazarEventosActualizar();
        }

        vistaActualizar.getTxtCodigo().setText(codigo);
        vistaActualizar.getTxtCodigo().setEditable(false);
        vistaActualizar.getTxtNombres().setText(nombres);
        vistaActualizar.getTxtApellidos().setText(apellidos);
        vistaActualizar.getTxtCorreo().setText(correo);
        vistaActualizar.getTxtContrasena().setText(contrasena);
        vistaActualizar.getCmbRol().setSelectedItem(rol);

        vistaActualizar.setVisible(true);

        if (vistaActualizar.getParent() == null) {
            if (contenedorActualizar == null || !contenedorActualizar.isDisplayable()) {
                contenedorActualizar = new JFrame("Actualizar Usuario");
                contenedorActualizar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                contenedorActualizar.setContentPane(vistaActualizar.getContentPane());
                contenedorActualizar.setSize(new Dimension(540, 440));
                contenedorActualizar.setLocationRelativeTo(vistaPerfiles);
            }
            contenedorActualizar.setVisible(true);
            contenedorActualizar.toFront();
        } else {
            vistaActualizar.toFront();
        }
    }

    // Guarda las modificaciones realizadas a la cuenta del usuario.
    private void guardarUsuarioActualizado() {
        if (vistaActualizar == null) {
            return;
        }

        String strCodigo = vistaActualizar.getTxtCodigo().getText().trim();
        String nombres = vistaActualizar.getTxtNombres().getText().trim();
        String apellidos = vistaActualizar.getTxtApellidos().getText().trim();
        String correo = vistaActualizar.getTxtCorreo().getText().trim();
        String contrasena = vistaActualizar.getTxtContrasena().getText().trim();
        String rol = vistaActualizar.getCmbRol().getSelectedItem() != null 
                ? vistaActualizar.getCmbRol().getSelectedItem().toString().trim() 
                : "";

        if (strCodigo.isEmpty() || nombres.isEmpty() || apellidos.isEmpty() || correo.isEmpty() || contrasena.isEmpty() || rol.isEmpty()) {
            JOptionPane.showMessageDialog(
                    (contenedorActualizar != null && contenedorActualizar.isVisible()) ? contenedorActualizar : vistaActualizar,
                    "Por favor, complete todos los campos obligatorios.",
                    "Campos Vacíos",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id;
        try {
            id = Integer.parseInt(strCodigo);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                    (contenedorActualizar != null && contenedorActualizar.isVisible()) ? contenedorActualizar : vistaActualizar,
                    "Código de usuario inválido.",
                    "Error de Formato",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        Usuario usuarioModificado = new Usuario(id, nombres, apellidos, correo, contrasena, rol);
        boolean resultado = dao.actualizar(usuarioModificado);

        if (resultado) {
            JOptionPane.showMessageDialog(
                    (contenedorActualizar != null && contenedorActualizar.isVisible()) ? contenedorActualizar : vistaActualizar,
                    "¡Usuario actualizado exitosamente!",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE
            );

            limpiarCamposActualizar();

            if (vistaPerfiles != null) {
                cargarTabla();
            }

            cerrarVentanaActualizar();
        } else {
            JOptionPane.showMessageDialog(
                    (contenedorActualizar != null && contenedorActualizar.isVisible()) ? contenedorActualizar : vistaActualizar,
                    "Error al actualizar el usuario en la base de datos.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void cerrarVentanaActualizar() {
        if (vistaActualizar != null) {
            vistaActualizar.dispose();
        }
        if (contenedorActualizar != null) {
            contenedorActualizar.dispose();
        }
    }

    // Deja en blanco las casillas de la ventana de modificación de usuario.
    private void limpiarCamposActualizar() {
        if (vistaActualizar != null) {
            vistaActualizar.getTxtCodigo().setText("");
            vistaActualizar.getTxtNombres().setText("");
            vistaActualizar.getTxtApellidos().setText("");
            vistaActualizar.getTxtCorreo().setText("");
            vistaActualizar.getTxtContrasena().setText("");
            if (vistaActualizar.getCmbRol().getItemCount() > 0) {
                vistaActualizar.getCmbRol().setSelectedIndex(0);
            }
        }
    }

    public boolean isVieneDeInicio() {
        return vieneDeInicio;
    }

    public void setVieneDeInicio(boolean vieneDeInicio) {
        this.vieneDeInicio = vieneDeInicio;
    }

    public Inicio getVistaInicio() {
        return vistaInicio;
    }

    public void setVistaInicio(Inicio vistaInicio) {
        this.vistaInicio = vistaInicio;
        enlazarVistaInicio();
    }

    public Crear_usuario getVista() { return vistaCrear; }
    public Crear_usuario getVistaCrear() { return vistaCrear; }
    public void setVistaCrear(Crear_usuario vistaCrear) { 
        this.vistaCrear = vistaCrear; 
        enlazarVistaCrear();
    }

    public Crear_perfiles getVistaPerfiles() { return vistaPerfiles; }
    public void setVistaPerfiles(Crear_perfiles vistaPerfiles) { 
        this.vistaPerfiles = vistaPerfiles; 
        enlazarVistaPerfiles();
    }

    public ActualizarU getVistaActualizar() { return vistaActualizar; }
    public void setVistaActualizar(ActualizarU vistaActualizar) { 
        this.vistaActualizar = vistaActualizar; 
        enlazarEventosActualizar();
    }

    public Usuario getModelo() { return modelo; }
    public void setModelo(Usuario modelo) { this.modelo = modelo; }

    public UsuarioDAO getDao() { return dao; }
    public void setDao(UsuarioDAO dao) { this.dao = dao; }
}
