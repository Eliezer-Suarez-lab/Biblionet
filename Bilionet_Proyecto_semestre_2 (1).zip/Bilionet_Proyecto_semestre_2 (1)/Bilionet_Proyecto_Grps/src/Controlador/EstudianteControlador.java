package Controlador;

import Modelo.Estudiante;
import Modelo.EstudianteDAO;
import Vista.Gestion_de_usuario_1;
import Vista.Gestion_de_usuario_tabla;
import java.awt.AWTEvent;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

// Coordina las pantallas de estudiantes: tanto la lista general como el formulario para dar de alta o modificar sus datos.
public class EstudianteControlador implements ActionListener {

    private Gestion_de_usuario_1 vistaFormulario;
    private Gestion_de_usuario_tabla vistaTabla;
    private Estudiante modelo;
    private EstudianteDAO dao;

    // Indica si se está inscribiendo un nuevo estudiante o modificando uno existente
    private boolean esActualizacion = false;

    private static boolean autoEnlaceRegistrado = false;
    private static final Set<Object> vistasControladas =
            Collections.newSetFromMap(new WeakHashMap<>());

    static {
        activarAutoEnlace();
    }

    // Conecta las pantallas de estudiantes de forma automática en cuanto se abren en el sistema.
    public static void activarAutoEnlace() {
        if (autoEnlaceRegistrado) {
            return;
        }
        autoEnlaceRegistrado = true;
        Toolkit.getDefaultToolkit().addAWTEventListener((AWTEvent event) -> {
            if (event.getID() == WindowEvent.WINDOW_OPENED || event.getID() == WindowEvent.WINDOW_ACTIVATED) {
                Object source = event.getSource();
                if (source instanceof Gestion_de_usuario_1) {
                    Gestion_de_usuario_1 vf = (Gestion_de_usuario_1) source;
                    if (!vistasControladas.contains(vf)) {
                        new EstudianteControlador(vf, new Gestion_de_usuario_tabla(), new Estudiante(), new EstudianteDAO());
                    }
                } else if (source instanceof Gestion_de_usuario_tabla) {
                    Gestion_de_usuario_tabla vt = (Gestion_de_usuario_tabla) source;
                    if (!vistasControladas.contains(vt)) {
                        new EstudianteControlador(new Gestion_de_usuario_1(), vt, new Estudiante(), new EstudianteDAO());
                    }
                }
            }
        }, AWTEvent.WINDOW_EVENT_MASK);
    }

    // Prepara las pantallas de estudiantes, calcula el siguiente número de carnet y muestra la lista completa.
    public EstudianteControlador(Gestion_de_usuario_1 vistaFormulario, Gestion_de_usuario_tabla vistaTabla, Estudiante modelo, EstudianteDAO dao) {
        this.vistaFormulario = (vistaFormulario != null) ? vistaFormulario : new Gestion_de_usuario_1();
        this.vistaTabla = (vistaTabla != null) ? vistaTabla : new Gestion_de_usuario_tabla();
        this.modelo = (modelo != null) ? modelo : new Estudiante();
        this.dao = (dao != null) ? dao : new EstudianteDAO();

        vistasControladas.add(this.vistaFormulario);
        vistasControladas.add(this.vistaTabla);

        this.vistaFormulario.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        this.vistaTabla.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        actualizarSiguienteCodigo();
        registrarEventos();
        cargarTabla();
    }

    // Prepara las pantallas de estudiantes.
    public EstudianteControlador(Gestion_de_usuario_tabla vistaTabla, Gestion_de_usuario_1 vistaFormulario, Estudiante modelo, EstudianteDAO dao) {
        this(vistaFormulario, vistaTabla, modelo, dao);
    }

    // Prepara las pantallas de estudiantes con su acceso a datos.
    public EstudianteControlador(Gestion_de_usuario_1 vistaFormulario, Gestion_de_usuario_tabla vistaTabla, EstudianteDAO dao) {
        this(vistaFormulario, vistaTabla, new Estudiante(), dao);
    }

    // Prepara las pantallas de estudiantes con su configuración habitual.
    public EstudianteControlador(Gestion_de_usuario_1 vistaFormulario, Gestion_de_usuario_tabla vistaTabla) {
        this(vistaFormulario, vistaTabla, new Estudiante(), new EstudianteDAO());
    }

    // Prepara el formulario de estudiantes.
    public EstudianteControlador(Gestion_de_usuario_1 vistaFormulario) {
        this(vistaFormulario, new Gestion_de_usuario_tabla(), new Estudiante(), new EstudianteDAO());
    }

    // Prepara la tabla con la lista de estudiantes.
    public EstudianteControlador(Gestion_de_usuario_tabla vistaTabla) {
        this(new Gestion_de_usuario_1(), vistaTabla, new Estudiante(), new EstudianteDAO());
    }

    // Conecta los botones de las pantallas (agregar, editar, borrar, buscar y guardar) para que respondan al hacer clic.
    private void registrarEventos() {
        if (this.vistaFormulario != null) {
            JButton btnGuardar = getBtnGuardar();
            if (btnGuardar != null) {
                btnGuardar.removeActionListener(this);
                btnGuardar.addActionListener(this);
            }
        }

        if (this.vistaTabla != null) {
            JButton btnAgregar = getBtnAgregar();
            if (btnAgregar != null) {
                btnAgregar.removeActionListener(this);
                btnAgregar.addActionListener(this);
            }
            JButton btnActualizar = getBtnActualizar();
            if (btnActualizar != null) {
                btnActualizar.removeActionListener(this);
                btnActualizar.addActionListener(this);
            }
            JButton btnEliminar = getBtnEliminar();
            if (btnEliminar != null) {
                btnEliminar.removeActionListener(this);
                btnEliminar.addActionListener(this);
            }
            JButton btnBuscar = getBtnBuscar();
            if (btnBuscar != null) {
                btnBuscar.removeActionListener(this);
                btnBuscar.addActionListener(this);
            }
            JTextField txtBuscar = getTxtBuscar();
            if (txtBuscar != null) {
                txtBuscar.removeActionListener(this);
                txtBuscar.addActionListener(this);
            }
        }
    }

    // Asigna automáticamente el siguiente número disponible al estudiante y protege la casilla para evitar escribir en ella.
    public void actualizarSiguienteCodigo() {
        JTextField txtCodigo = getTxtCodigo();
        if (txtCodigo != null) {
            txtCodigo.setEditable(false);
            int siguienteId = dao.obtenerSiguienteId();
            txtCodigo.setText(String.valueOf(siguienteId));
        }
    }

    // Deja en blanco todas las casillas del formulario para poder ingresar un nuevo estudiante desde cero.
    public void limpiarFormulario() {
        if (getTxtNombres() != null) {
            getTxtNombres().setText("");
        }
        if (getTxtApellidos() != null) {
            getTxtApellidos().setText("");
        }
        if (getTxtTelefono() != null) {
            getTxtTelefono().setText("");
        }

        limpiarCampoOCombo(getComponenteTipoUsuario());
        limpiarCampoOCombo(getComponenteSeccion());
        limpiarCampoOCombo(getComponenteAnio());

        actualizarSiguienteCodigo();
    }

    private void limpiarCampoOCombo(JComponent comp) {
        if (comp instanceof JTextField) {
            ((JTextField) comp).setText("");
        } else if (comp instanceof JComboBox) {
            JComboBox<?> combo = (JComboBox<?>) comp;
            if (combo.getItemCount() > 0) {
                combo.setSelectedIndex(0);
            }
        }
    }

    private void asignarValorCampoOCombo(JComponent comp, String valor) {
        if (comp instanceof JTextField) {
            ((JTextField) comp).setText(valor != null ? valor : "");
        } else if (comp instanceof JComboBox) {
            ((JComboBox<?>) comp).setSelectedItem(valor);
        }
    }

    private String extraerValorCampoOCombo(JComponent comp) {
        if (comp instanceof JTextField) {
            return ((JTextField) comp).getText().trim();
        } else if (comp instanceof JComboBox) {
            Object item = ((JComboBox<?>) comp).getSelectedItem();
            return (item != null) ? item.toString().trim() : "";
        }
        return "";
    }

    // Abre la ventana limpia para escribir los datos de un nuevo estudiante.
    public void abrirFormularioAgregar() {
        if (this.vistaFormulario == null) {
            this.vistaFormulario = new Gestion_de_usuario_1();
            this.vistaFormulario.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
            registrarEventos();
        }

        this.esActualizacion = false;
        limpiarFormulario();

        if (getTxtCodigo() != null) {
            getTxtCodigo().setEditable(false);
            getTxtCodigo().setText(String.valueOf(dao.obtenerSiguienteId()));
        }

        this.vistaFormulario.setLocationRelativeTo(null);
        this.vistaFormulario.setVisible(true);
        this.vistaFormulario.toFront();
    }

    // Abre la ventana cargando los datos del estudiante elegido para que podamos modificarlos.
    public void abrirFormularioActualizar() {
        JTable tabla = getTablaEstudiantes();
        if (tabla == null) {
            return;
        }

        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(
                    vistaTabla,
                    "Por favor, seleccione un estudiante de la tabla para actualizar.",
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        String nombres = String.valueOf(tabla.getValueAt(fila, 0));
        String apellidos = String.valueOf(tabla.getValueAt(fila, 1));
        String telefono = String.valueOf(tabla.getValueAt(fila, 2));
        String tipoUsuario = String.valueOf(tabla.getValueAt(fila, 3));
        String seccion = String.valueOf(tabla.getValueAt(fila, 4));
        String anio = String.valueOf(tabla.getValueAt(fila, 5));
        String codigo = String.valueOf(tabla.getValueAt(fila, 6));

        if (this.vistaFormulario == null) {
            this.vistaFormulario = new Gestion_de_usuario_1();
            this.vistaFormulario.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
            registrarEventos();
        }

        this.esActualizacion = true;

        if (getTxtNombres() != null) {
            getTxtNombres().setText(nombres);
        }
        if (getTxtApellidos() != null) {
            getTxtApellidos().setText(apellidos);
        }
        if (getTxtTelefono() != null) {
            getTxtTelefono().setText(telefono);
        }

        asignarValorCampoOCombo(getComponenteTipoUsuario(), tipoUsuario);
        asignarValorCampoOCombo(getComponenteSeccion(), seccion);
        asignarValorCampoOCombo(getComponenteAnio(), anio);

        if (getTxtCodigo() != null) {
            getTxtCodigo().setText(codigo);
            getTxtCodigo().setEditable(false);
        }

        this.vistaFormulario.setLocationRelativeTo(null);
        this.vistaFormulario.setVisible(true);
        this.vistaFormulario.toFront();
    }

    // Pide confirmación al usuario y retira al estudiante seleccionado de la lista.
    public void eliminarEstudiante() {
        JTable tabla = getTablaEstudiantes();
        if (tabla == null) {
            return;
        }

        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(
                    vistaTabla,
                    "Por favor, seleccione un estudiante de la tabla para eliminar.",
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = Integer.parseInt(tabla.getValueAt(fila, 6).toString());

        int confirmacion = JOptionPane.showConfirmDialog(
                vistaTabla,
                "¿Está seguro de que desea eliminar al estudiante con código " + id + "?",
                "Confirmación de Eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            boolean eliminado = dao.eliminar(id);
            if (eliminado) {
                JOptionPane.showMessageDialog(
                        vistaTabla,
                        "¡Estudiante eliminado correctamente!",
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE
                );
                cargarTabla();
            } else {
                JOptionPane.showMessageDialog(
                        vistaTabla,
                        "Error al eliminar el estudiante de la base de datos.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }

    // Busca a los estudiantes que coincidan con el nombre, apellido o dato que escribimos.
    public void buscarEstudiantes() {
        JTable tabla = getTablaEstudiantes();
        if (tabla == null) {
            return;
        }

        JTextField txtBuscar = getTxtBuscar();
        String filtro = (txtBuscar != null) ? txtBuscar.getText().trim() : "";

        if (filtro.isEmpty()) {
            cargarTabla();
            return;
        }

        String[] columnas = {"Nombres", "Apellidos", "Telefono", "Tipo-usuario", "Seccion", "Año", "Codigo"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        List<Estudiante> lista = dao.buscar(filtro);
        if (lista != null) {
            for (Estudiante est : lista) {
                Object[] fila = new Object[7];
                fila[0] = est.getNombres();
                fila[1] = est.getApellidos();
                fila[2] = est.getTelefono();
                fila[3] = est.getTipo_usuario();
                fila[4] = est.getSeccion();
                fila[5] = est.getAnio();
                fila[6] = est.getCodigo();
                modeloTabla.addRow(fila);
            }
        }

        tabla.setModel(modeloTabla);
    }

    // Revisa que no falte ningún dato y guarda o actualiza la ficha del estudiante en el sistema.
    public void guardarEstudiante() {
        if (this.vistaFormulario == null) {
            return;
        }

        String codigoStr = (getTxtCodigo() != null) ? getTxtCodigo().getText().trim() : "";
        String nombres = (getTxtNombres() != null) ? getTxtNombres().getText().trim() : "";
        String apellidos = (getTxtApellidos() != null) ? getTxtApellidos().getText().trim() : "";
        String telefono = (getTxtTelefono() != null) ? getTxtTelefono().getText().trim() : "";
        String tipoUsuario = extraerValorCampoOCombo(getComponenteTipoUsuario());
        String seccion = extraerValorCampoOCombo(getComponenteSeccion());
        String anio = extraerValorCampoOCombo(getComponenteAnio());

        if (nombres.isEmpty() || apellidos.isEmpty() || telefono.isEmpty()
                || tipoUsuario.isEmpty() || seccion.isEmpty() || anio.isEmpty()) {
            JOptionPane.showMessageDialog(
                    vistaFormulario,
                    "Por favor, complete todos los campos del formulario.",
                    "Campos Vacíos",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        Estudiante estudiante = new Estudiante(nombres, apellidos, telefono, tipoUsuario, seccion, anio);
        if (!codigoStr.isEmpty()) {
            try {
                estudiante.setCodigo(Integer.parseInt(codigoStr));
            } catch (NumberFormatException ignored) {
            }
        }
        this.modelo = estudiante;

        if (esActualizacion) {
            boolean actualizado = dao.actualizar(estudiante);
            if (actualizado) {
                JOptionPane.showMessageDialog(
                        vistaFormulario,
                        "¡Estudiante actualizado exitosamente!",
                        "Actualización Exitosa",
                        JOptionPane.INFORMATION_MESSAGE
                );
                limpiarFormulario();
                cargarTabla();
                vistaFormulario.dispose();
            } else {
                JOptionPane.showMessageDialog(
                        vistaFormulario,
                        "Error al actualizar el estudiante en la base de datos.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        } else {
            boolean registrado = dao.registrar(estudiante);
            if (registrado) {
                JOptionPane.showMessageDialog(
                        vistaFormulario,
                        "¡Estudiante registrado exitosamente!",
                        "Registro Exitoso",
                        JOptionPane.INFORMATION_MESSAGE
                );
                limpiarFormulario();
                cargarTabla();
                vistaFormulario.dispose();
            } else {
                JOptionPane.showMessageDialog(
                        vistaFormulario,
                        "Error al registrar el estudiante en la base de datos.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }

    // Muestra en la tabla la lista actualizada de todos los estudiantes registrados.
    public void cargarTabla() {
        JTable tabla = getTablaEstudiantes();
        if (tabla == null) {
            return;
        }

        String[] columnas = {"Nombres", "Apellidos", "Telefono", "Tipo-usuario", "Seccion", "Año", "Codigo"};
        DefaultTableModel modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        List<Estudiante> lista = dao.listar();
        if (lista != null) {
            for (Estudiante est : lista) {
                Object[] fila = new Object[7];
                fila[0] = est.getNombres();
                fila[1] = est.getApellidos();
                fila[2] = est.getTelefono();
                fila[3] = est.getTipo_usuario();
                fila[4] = est.getSeccion();
                fila[5] = est.getAnio();
                fila[6] = est.getCodigo();
                modeloTabla.addRow(fila);
            }
        }

        tabla.setModel(modeloTabla);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (vistaTabla != null && source == getBtnAgregar()) {
            abrirFormularioAgregar();
        } else if (vistaTabla != null && source == getBtnActualizar()) {
            abrirFormularioActualizar();
        } else if (vistaTabla != null && source == getBtnEliminar()) {
            eliminarEstudiante();
        } else if (vistaTabla != null && (source == getBtnBuscar() || source == getTxtBuscar())) {
            buscarEstudiantes();
        } else if (vistaFormulario != null && source == getBtnGuardar()) {
            guardarEstudiante();
        }
    }

    private JTextField getTxtCodigo() {
        return obtenerComponente(vistaFormulario, JTextField.class,
                new String[]{"getTxtCodigo", "getTxtId", "getJTextField7", "getJTextField6", "getJTextField5"},
                new String[]{"TxtCodigo", "txtCodigo", "jTextField7", "jTextField6", "jTextField5"});
    }

    private JTextField getTxtNombres() {
        return obtenerComponente(vistaFormulario, JTextField.class,
                new String[]{"getTxtNombres", "getTxtNombre", "getJTextField1"},
                new String[]{"TxtNombres", "txtNombres", "TxtNombre", "jTextField1"});
    }

    private JTextField getTxtApellidos() {
        return obtenerComponente(vistaFormulario, JTextField.class,
                new String[]{"getTxtApellidos", "getTxtApellido", "getJTextField2"},
                new String[]{"TxtApellidos", "txtApellidos", "TxtApellido", "jTextField2"});
    }

    private JTextField getTxtTelefono() {
        return obtenerComponente(vistaFormulario, JTextField.class,
                new String[]{"getTxtTelefono", "getJTextField3"},
                new String[]{"TxtTelefono", "txtTelefono", "jTextField3"});
    }

    private JComponent getComponenteTipoUsuario() {
        return obtenerComponente(vistaFormulario, JComponent.class,
                new String[]{"getTxtTipoUsuario", "getTxtTipo_usuario", "getCmbTipoUsuario", "getCmbTipo", "getJTextField4"},
                new String[]{"TxtTipoUsuario", "txtTipoUsuario", "CmbTipoUsuario", "cmbTipoUsuario", "jTextField4"});
    }

    private JComponent getComponenteSeccion() {
        return obtenerComponente(vistaFormulario, JComponent.class,
                new String[]{"getTxtSeccion", "getCmbSeccion", "getJTextField5"},
                new String[]{"TxtSeccion", "txtSeccion", "CmbSeccion", "cmbSeccion", "jTextField5"});
    }

    private JComponent getComponenteAnio() {
        return obtenerComponente(vistaFormulario, JComponent.class,
                new String[]{"getTxtAnio", "getTxtAño", "getCmbAnio", "getCmbAño", "getJTextField6"},
                new String[]{"TxtAnio", "txtAnio", "TxtAño", "txtAño", "CmbAnio", "cmbAnio", "jTextField6"});
    }

    private JButton getBtnGuardar() {
        return obtenerComponente(vistaFormulario, JButton.class,
                new String[]{"getBtnGuardar", "getBtnRegistrar", "getBtnSiguiente", "getBtnAgregar", "getJButton4"},
                new String[]{"BtnGuardar", "btnGuardar", "BtnSiguiente", "BtnAgregar", "jButton4"});
    }

    private JTable getTablaEstudiantes() {
        return obtenerComponente(vistaTabla, JTable.class,
                new String[]{"getTablaEstudiantes", "getTablaUsuarios", "getTabla", "getJTable1"},
                new String[]{"TablaEstudiantes", "tablaEstudiantes", "TablaUsuarios", "jTable1"});
    }

    private JButton getBtnAgregar() {
        return obtenerComponente(vistaTabla, JButton.class,
                new String[]{"getBtnAgregar", "getBtnCrear", "getBtnNuevo", "getJButton4"},
                new String[]{"BtnAgregar", "btnAgregar", "BtnCrear", "jButton4"});
    }

    private JButton getBtnActualizar() {
        return obtenerComponente(vistaTabla, JButton.class,
                new String[]{"getBtnActualizar", "getBtnEditar", "getBtnModificar"},
                new String[]{"BtnActualizar", "btnActualizar", "BtnEditar"});
    }

    private JButton getBtnEliminar() {
        return obtenerComponente(vistaTabla, JButton.class,
                new String[]{"getBtnEliminar", "getBtnBorrar"},
                new String[]{"BtnEliminar", "btnEliminar"});
    }

    private JButton getBtnBuscar() {
        return obtenerComponente(vistaTabla, JButton.class,
                new String[]{"getBtnBuscar"},
                new String[]{"BtnBuscar", "btnBuscar"});
    }

    private JTextField getTxtBuscar() {
        return obtenerComponente(vistaTabla, JTextField.class,
                new String[]{"getTxtBuscar", "getJTextField1"},
                new String[]{"TxtBuscar", "txtBuscar", "jTextField1"});
    }

    @SuppressWarnings("unchecked")
    private <T> T obtenerComponente(Object vistaObj, Class<T> tipo, String[] nombresGetters, String[] nombresCampos) {
        if (vistaObj == null) {
            return null;
        }
        for (String nombreMetodo : nombresGetters) {
            try {
                Method m = vistaObj.getClass().getMethod(nombreMetodo);
                Object resultado = m.invoke(vistaObj);
                if (tipo.isInstance(resultado)) {
                    return (T) resultado;
                }
            } catch (Exception ignored) {
            }
        }
        for (String nombreCampo : nombresCampos) {
            try {
                Field f = vistaObj.getClass().getDeclaredField(nombreCampo);
                f.setAccessible(true);
                Object resultado = f.get(vistaObj);
                if (tipo.isInstance(resultado)) {
                    return (T) resultado;
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }
}
