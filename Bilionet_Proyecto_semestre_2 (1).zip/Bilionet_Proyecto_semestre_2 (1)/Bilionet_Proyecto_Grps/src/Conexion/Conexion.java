package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Gestor centralizado de conexiones JDBC a MySQL (biblionet1).
 * Inyecta dinámicamente las variables de sesión @app_correo y @app_rol en MySQL
 * para que todos los disparadores (triggers) de la tabla Bitacora registren
 * con total precisión el usuario de la aplicación y su rol correspondiente.
 */
public class Conexion {

    private static final String URL = "jdbc:mysql://localhost:3307/biblionet1?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    // Credenciales por defecto para operaciones de arranque y login inicial
    private static final String USUARIO_DEFAULT = "root";
    private static final String PASSWORD_DEFAULT = "eAntonio18";

    // Variables activas de la sesión
    private static String usuarioActual = USUARIO_DEFAULT;
    private static String passwordActual = PASSWORD_DEFAULT;
    private static String rolActual = null;
    private static String correoActual = null;

    /**
     * Establece las credenciales activas del usuario autenticado en el sistema
     * e inyecta de inmediato las variables de sesión @app_correo y @app_rol en MySQL.
     * 
     * @param correo Correo electrónico de la persona que inició sesión.
     * @param rol Rol del usuario en el sistema ('Administrador' o 'Bibliotecario').
     */
    public static void establecerSesion(String correo, String rol) {
        correoActual = (correo != null) ? correo.trim() : null;
        rolActual = (rol != null) ? rol.trim() : "SISTEMA";

        if (rolActual.equalsIgnoreCase("Administrador")) {
            usuarioActual = "administrador";
            passwordActual = "AdminBiblio2026!";
        } else if (rolActual.equalsIgnoreCase("Bibliotecario")) {
            usuarioActual = "bibliotecario";
            passwordActual = "BiblioUser2026!";
        } else {
            usuarioActual = USUARIO_DEFAULT;
            passwordActual = PASSWORD_DEFAULT;
        }

        // Ejecutar inmediatamente en la conexión activa las dos variables de sesión
        try (Connection con = DriverManager.getConnection(URL, usuarioActual, passwordActual);
             PreparedStatement ps1 = con.prepareStatement("SET @app_correo = ?");
             PreparedStatement ps2 = con.prepareStatement("SET @app_rol = ?")) {

            ps1.setString(1, correoActual);
            ps1.execute();

            ps2.setString(1, rolActual);
            ps2.execute();

            System.out.println(">> [SESIÓN INICIADA EN MYSQL] Usuario: " + correoActual + " | Rol: " + rolActual);

        } catch (SQLException e) {
            System.err.println(">> [ERROR] Al inyectar variables de sesión en MySQL: " + e.getMessage());
        }
    }

    /**
     * Sobrecarga de compatibilidad para cambiar sesión por rol y correo.
     */
    public static boolean cambiarSesion(String rol, String correo) {
        establecerSesion(correo, rol);
        return true;
    }

    /**
     * Sobrecarga de compatibilidad para cambiar sesión solo por rol.
     */
    public static boolean cambiarSesion(String rol) {
        establecerSesion(null, rol);
        return true;
    }

    /**
     * Restablece las variables de sesión y credenciales por defecto al cerrar sesión.
     */
    public static void resetearCredenciales() {
        usuarioActual = USUARIO_DEFAULT;
        passwordActual = PASSWORD_DEFAULT;
        rolActual = null;
        correoActual = null;
        System.out.println(">> [SEGURIDAD] Sesión restablecida a valores por defecto.");
    }

    /**
     * Retorna una conexión activa a MySQL inyectando automáticamente @app_correo y @app_rol
     * en cada conexión abierta por los DAOs para que los triggers registren siempre los datos reales.
     * 
     * @return Connection activa o null si ocurre un fallo.
     */
    public static Connection conectar() {
        Connection con = null;
        try {
            con = DriverManager.getConnection(URL, usuarioActual, passwordActual);

            // Inyectar automáticamente las variables de sesión activas
            if (correoActual != null || rolActual != null) {
                try (PreparedStatement ps1 = con.prepareStatement("SET @app_correo = ?");
                     PreparedStatement ps2 = con.prepareStatement("SET @app_rol = ?")) {

                    ps1.setString(1, correoActual);
                    ps1.execute();

                    ps2.setString(1, (rolActual != null) ? rolActual : "SISTEMA");
                    ps2.execute();

                } catch (SQLException ignore) {
                    // Si falla el SET, la conexión principal sigue disponible
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al conectar a MySQL (" + usuarioActual + "): " + e.getMessage());
            // Fallback de contingencia a root
            if (!USUARIO_DEFAULT.equals(usuarioActual)) {
                try {
                    con = DriverManager.getConnection(URL, USUARIO_DEFAULT, PASSWORD_DEFAULT);
                    if (correoActual != null || rolActual != null) {
                        try (PreparedStatement ps1 = con.prepareStatement("SET @app_correo = ?");
                             PreparedStatement ps2 = con.prepareStatement("SET @app_rol = ?")) {
                            ps1.setString(1, correoActual);
                            ps1.execute();
                            ps2.setString(1, (rolActual != null) ? rolActual : "SISTEMA");
                            ps2.execute();
                        } catch (SQLException ignore) {}
                    }
                } catch (SQLException exFallback) {
                    System.err.println("Error crítico en conexión de respaldo: " + exFallback.getMessage());
                }
            }
        }
        return con;
    }

    public static String getUsuarioActual() {
        return usuarioActual;
    }

    public static String getRolActual() {
        return rolActual;
    }

    public static String getCorreoActual() {
        return correoActual;
    }
}
